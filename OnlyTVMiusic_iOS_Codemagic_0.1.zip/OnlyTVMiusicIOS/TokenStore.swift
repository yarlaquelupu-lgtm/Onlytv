import Foundation
import Security
import CryptoKit

/// Guarde solamente el token de sesión y la identidad local aleatoria.
/// Nunca registre contraseñas, tokens ni URLs privadas en logs.
enum TokenStore {
    private static let service = "com.onlytvmiusic.ios"

    static func read(_ key: String) -> String? {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: key,
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne
        ]
        var result: CFTypeRef?
        guard SecItemCopyMatching(query as CFDictionary, &result) == errSecSuccess,
              let data = result as? Data else { return nil }
        return String(data: data, encoding: .utf8)
    }

    static func write(_ value: String, key: String) {
        let selector: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: key
        ]
        SecItemDelete(selector as CFDictionary)
        var item = selector
        item[kSecValueData as String] = Data(value.utf8)
        item[kSecAttrAccessible as String] = kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
        let status = SecItemAdd(item as CFDictionary, nil)
        assert(status == errSecSuccess, "Error guardando Keychain")
    }

    static func delete(_ key: String) {
        let selector: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: key
        ]
        SecItemDelete(selector as CFDictionary)
    }

    /// Identificador distinto al de Android, estable mientras conserve Keychain.
    static func deviceID() -> String {
        let localID: String
        if let saved = read("deviceUUID"), !saved.isEmpty { localID = saved }
        else { localID = UUID().uuidString; write(localID, key: "deviceUUID") }
        let hash = SHA256.hash(data: Data((service + ":" + localID).utf8))
        return hash.map { String(format: "%02x", $0) }.joined()
    }
}
