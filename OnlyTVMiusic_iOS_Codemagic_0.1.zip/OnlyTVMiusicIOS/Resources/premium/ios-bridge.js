/* Capa de compatibilidad temporal para la interfaz Android.
 * WKWebView utiliza mensajes ASÍNCRONOS; Android @JavascriptInterface
 * devolvía valores síncronos. Conservamos datos de lectura en memoria JS.
 * La base iOS solo implementa sesión, demo, perfiles y banners.
 * No afirma reproducir música ni tener sincronización de bibliotecas.
 */
(() => {
  'use strict';
  const blankState = {
    loggedIn: false, sessionReady: false, username: '', accountType: 'normal',
    profiles: [], activeProfileId: 0, profileSelectionRequired: false,
    isDemo: false, startsOn: '', expiresAt: '', favorites: [], history: [],
    playlists: [], recent: [], followed: [], librarySyncedAt: 0, playback: {}
  };
  window.__OnlyTViOSBoot = window.__OnlyTViOSBoot || blankState;
  let requestId = 0;
  const post = (name, args = []) => {
    try { window.webkit.messageHandlers.onlytv.postMessage({name, args}); }
    catch (err) { console.warn('iOS bridge', name, err); }
  };
  const noopWarning = () => {if (window.OnlyTVApp) window.OnlyTVApp.notify('Esta función aún está pendiente de adaptar para iPhone.');};
  window.OnlyTVNative = {
    bootstrap: () => JSON.stringify(window.__OnlyTViOSBoot || blankState),
    playback: () => JSON.stringify(window.__OnlyTViOSBoot.playback || {}),
    favorites: () => JSON.stringify(window.__OnlyTViOSBoot.favorites || []),
    history: () => JSON.stringify(window.__OnlyTViOSBoot.history || []),
    playlists: () => JSON.stringify(window.__OnlyTViOSBoot.playlists || []),
    playlistTracks: () => '[]',
    searches: () => JSON.stringify(window.__OnlyTViOSBoot.recent || []),
    followed: () => JSON.stringify(window.__OnlyTViOSBoot.followed || []),
    queue: () => '[]',
    cachedTrending: () => '[]',
    shareLink: () => '',
    isFavorite: () => false,
    toggleFavorite: () => (noopWarning(), false),
    followArtist: () => (noopWarning(), false),
    createPlaylist: () => (noopWarning(), '{}'),
    renamePlaylist: () => (noopWarning(), false),
    deletePlaylist: () => (noopWarning(), false),
    addToPlaylist: () => (noopWarning(), false),
    removeFromPlaylist: () => (noopWarning(), false),
    rememberSearch: () => {},
    clearSearches: () => noopWarning(),
    loadBanners: () => post('loadBanners'),
    loadDemos: () => post('loadDemos'),
    demoSignIn: (id) => post('demoSignIn', [id]),
    signIn: (username, password) => post('signIn', [username, password]),
    transferSignIn: (username, password) => post('transferSignIn', [username, password]),
    selectProfile: (id) => post('selectProfile', [id]),
    switchProfile: () => post('switchProfile'),
    logout: () => post('logout'),
    localLogout: () => post('localLogout'),
    verifySession: () => post('verifySession'),
    webReady: () => post('webReady'),
    search: (query, trending) => {const id=++requestId;post('search',[query,!!trending,id]);return id;},
    searchArtist: () => noopWarning(),
    loadArtistCharts: () => {},
    loadArtistInfo: () => {},
    play: () => noopWarning(),
    command: () => noopWarning(),
    syncLibrary: () => noopWarning(),
    clearHistoryOnDevice: () => noopWarning(),
    clearLibrary: () => noopWarning(),
    planExpiryReached: () => {},
    checkAppUpdate: () => {if (window.OnlyTVApp) window.OnlyTVApp.notify('Las actualizaciones para iPhone se distribuyen por iOS.');},
    openRenewalWhatsApp: (message) => post('openRenewalWhatsApp',[message]),
    shareTrack: () => noopWarning(),
    shareChatCard: () => noopWarning(),
    shareStatusCard: () => noopWarning(),
    copyShareLink: () => noopWarning(),
    shareLinkText: () => noopWarning(),
    ackSharedSong: () => {},
    leave: () => {},
  };
})();
