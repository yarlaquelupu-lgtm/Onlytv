(()=>{
'use strict';
const Native=window.OnlyTVNative||null;
const S={loggedIn:false,sessionReady:false,username:'',page:'home',results:[],trending:[],favorites:[],history:[],playlists:[],followed:[],recent:[],playback:{},artists:[],searchTerm:'',searchFilter:'all',loading:false,requestId:0,listMap:{},listId:0,detail:null,modal:null,seekHolding:false,playerOpen:false,logoutBusy:false,banners:[],bannersLoaded:false,bannerIndex:0,bannerLoadedAt:0,chartArtists:[],chartState:'idle',chartLoadedAt:0,artistSearch:{},artistInfo:{},artistInfoPending:{},playContext:null,playerSuggestions:[],trendingLoading:false,trendingRequested:false,trendingRequestId:0,trendingCacheLoaded:false,trendingError:'',queueOpen:false,queueLastKey:'',accountType:'normal',accountProfiles:[],activeProfileId:0,isDemo:false,expiresAt:'',startsOn:'',librarySyncedAt:0,demoLoading:false,noticeShownFor:"",planExpired:false,libraryOperationBusy:false,historySelecting:false,historySelected:new Set()};
const $=id=>document.getElementById(id);
const esc=(v)=>String(v==null?'':v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const icon=(name,cl='')=>`<svg class="i ${cl}" aria-hidden="true"><use href="#i-${name}"></use></svg>`;
const cover=(url)=>typeof url==='string'&&/^https:\/\//i.test(url)?url:'icon.png';
// NewPipe search can provide only a tiny preview. Use high-resolution artwork
// for the SAME video when available, keeping the actual source image as fallback.
const ytVideoId=t=>{
 if(!t||t.provider!=='newpipe')return '';
 try{const u=new URL(t.id);if(u.protocol!=='https:'|| !['www.youtube.com','music.youtube.com'].includes(u.hostname))return '';
 const id=u.searchParams.get('v')||'';return /^[A-Za-z0-9_-]{11}$/.test(id)?id:'';}catch(e){return ''}
};
const youtubeHq=t=>{const id=ytVideoId(t);return id?`https://i.ytimg.com/vi/${id}/hqdefault.jpg`:''};
// YouTube hqdefault/sddefault files can be 4:3 with black bars baked into
// the picture itself. Frame and crop them immediately instead of waiting for
// playback/maxres to replace the thumbnail and change its appearance.
const isLetterboxedVideoArt=(url)=>/^https:\/\/i\.ytimg\.com\/vi\/[A-Za-z0-9_-]{11}\/(?:hqdefault|sddefault)\.jpg(?:[?#].*)?$/i.test(String(url||''));
const frameArtwork=(image,url)=>{
 if(!image)return;
 image.classList.toggle('yt-letterbox',isLetterboxedVideoArt(url));
};
const resizedGoogleArt=url=>{
 if(!url || typeof url!=='string')return '';
 try{const u=new URL(url);
  if(u.protocol!=='https:' || !/^(?:lh[0-9]+\.)?googleusercontent\.com$/.test(u.hostname))return '';
  const resized=url.replace(/=w[0-9]+-h[0-9]+/,'=w640-h640');
  return resized!==url?resized:'';
 }catch(e){return ''}
};
const highArt=(t,large=false)=>{
 if(!t)return 'icon.png';
 if(t.provider!=='newpipe')return cover(large?(t.artworkLarge||t.artwork):t.artwork);
 return resizedGoogleArt(t.artwork) || cover(t.artworkLarge||youtubeHq(t)||t.artwork);
};
const fallbackArt=t=>cover(t&&t.artwork);
const artworkFallback=image=>{
 const options=[image.dataset.sd||'',image.dataset.hq||'',image.dataset.fallback||'','icon.png'];
 const attempted=(image.dataset.tried||'').split('|').filter(Boolean);
 let next='';
 for(const url of options){if(url&&!attempted.includes(url)&&url!==image.getAttribute('src')){next=url;break;}}
 if(next){
  image.dataset.tried=[...attempted,image.getAttribute('src')||''].filter(Boolean).join('|');
  frameArtwork(image,next);image.src=next;
 }else{
  image.onerror=null;image.onload=null;frameArtwork(image,'icon.png');image.src='icon.png';
 }
};
const artworkLoaded=image=>{
 if(!image.naturalWidth)return;
 frameArtwork(image,image.currentSrc||image.src);
 if(image.naturalWidth<180&&image.src!=='icon.png'&&image.dataset.artStage!=='final'){
  if(image.dataset.tried&&image.dataset.tried.split('|').length>2)image.dataset.artStage='final';
  else{artworkFallback(image);return;}
 }
 // HD is available before playback: only probe artwork that is already visible,
 // and never replace an existing cover until the new image is verified.
 const max=image.dataset.max||'';
 if(!max||image.dataset.maxProbed==='yes'||image.dataset.artStage==='maxres')return;
 const rect=image.getBoundingClientRect();
 if(rect.bottom<0||rect.top>window.innerHeight*1.35)return;
 image.dataset.maxProbed='yes';
 const original=image.getAttribute('src');
 const probe=new Image();
 probe.onload=()=>{
  if(!image.isConnected||image.dataset.artStage==='maxres')return;
  if(probe.naturalWidth>=640&&probe.naturalHeight>=360){
    image.dataset.artStage='maxres';image.src=probe.src;
  }
 };
 probe.onerror=()=>{};
 probe.src=max;
};
window.OnlyTVArtworkFallback=artworkFallback;
window.OnlyTVArtworkLoaded=artworkLoaded;
const artImg=(t,cls,lazy=true)=>{
 const id=ytVideoId(t),max=id?`https://i.ytimg.com/vi/${id}/maxresdefault.jpg`:'';
 const sd=id?`https://i.ytimg.com/vi/${id}/sddefault.jpg`:'';
 const primary=highArt(t);
 // Google-hosted album covers already have a 640px square rendition.
 const needsMax=id&&!resizedGoogleArt(t.artwork);
 return `<img class="${cls}${isLetterboxedVideoArt(primary)?' yt-letterbox':''}" src="${esc(primary)}" data-fallback="${esc(fallbackArt(t))}" data-hq="${esc(youtubeHq(t))}" data-sd="${esc(sd)}" data-max="${esc(needsMax?max:'')}" onerror="window.OnlyTVArtworkFallback(this)" onload="window.OnlyTVArtworkLoaded(this)" loading="${lazy?'lazy':'eager'}" decoding="async" alt="Portada">`;
};
const fmt=ms=>{let n=Math.floor(Math.max(0,Number(ms)||0)/1000);return Math.floor(n/60)+':'+String(n%60).padStart(2,'0')};
const native=(name,...args)=>{try{if(Native&&typeof Native[name]==='function')return Native[name](...args)}catch(err){console.warn(name,err)}return null};
const parse=(txt,alt)=>{try{return typeof txt==='string'?JSON.parse(txt):txt||alt}catch(e){return alt}};
const hydrate=()=>{
  let data=parse(native('bootstrap'),{});
  S.loggedIn=!!data.loggedIn;S.sessionReady=!!data.sessionReady;S.username=data.username||'';
  S.favorites=data.favorites||[];S.history=data.history||[];S.playlists=data.playlists||[];S.recent=data.recent||[];S.followed=data.followed||[];
  S.playback=data.playback||{};
  S.accountType=data.accountType||'normal';S.accountProfiles=data.profiles||[];
  S.activeProfileId=Number(data.activeProfileId||0);S.isDemo=!!data.isDemo;
  S.expiresAt=data.expiresAt||'';S.startsOn=data.startsOn||'';S.librarySyncedAt=Number(data.librarySyncedAt||0);
  if(S.loggedIn)checkPlanNotice();
  else if(!S.planExpired){$('plan-overlay').classList.add('hidden');S.noticeShownFor='';}
  const showProfiles=S.loggedIn&&data.profileSelectionRequired;
  $('login').classList.toggle('hidden',S.loggedIn);
  $('profile-picker').classList.toggle('hidden',!showProfiles);
  $('shell').classList.toggle('hidden',!S.loggedIn||showProfiles);
  if(showProfiles){renderProfilePicker();return;}
  const current=S.accountProfiles.find(x=>Number(x.id)===S.activeProfileId);
  const avatar=current&&/^avatar[1-8]$/.test(current.avatar)?current.avatar:'avatar1';
  $('account-avatar').src='avatars/'+avatar+'.png';
  if(!S.loggedIn){S.playerOpen=false;S.queueOpen=false;$('player-screen').classList.add('hidden');$('player-queue-sheet').classList.add('hidden');document.body.classList.remove('player-active');return}
  if(!S.trendingCacheLoaded){
    const cached=parse(native('cachedTrending'),[]);
    if(Array.isArray(cached)&&cached.length){S.trending=cached;}
    S.trendingCacheLoaded=true;
  }
  if(S.sessionReady&&!S.trendingRequested){loadTrending(false);}
  if(S.sessionReady&&(!S.bannersLoaded||Date.now()-S.bannerLoadedAt>300000)){S.bannersLoaded=true;S.bannerLoadedAt=Date.now();native('loadBanners');}
  if(S.sessionReady&&(S.chartState==='idle'||Date.now()-S.chartLoadedAt>21600000)){
    S.chartState='loading';S.chartLoadedAt=Date.now();native('loadArtistCharts');
  }
  render();renderPlayer();
};
const playerTrack=()=>S.playback.track&&S.playback.track.id?S.playback.track:null;
const listKey=list=>{const id='L'+(++S.listId);S.listMap[id]=list;return id};
function renderProfilePicker(){
 const profiles=S.accountProfiles||[];
 const count=$('profiles-count');
 const available=profiles.filter(p=>!p.busy).length;
 if(count)count.innerHTML=`<span class="profiles-count-mark"></span><strong>${available}</strong> ${available===1?'perfil disponible':'perfiles disponibles'}`;
 $('profiles-grid').innerHTML=profiles.map(p=>{
  const avatar=/^avatar[1-8]$/.test(p.avatar||'')?p.avatar:'avatar1';
  const name=esc(p.name||'Mi perfil');
  const busy=!!p.busy;
  return `<button type="button" class="profile-choice ${busy?'profile-busy':''}" data-act="select-profile" data-id="${Number(p.id)}" aria-label="${name}: ${busy?'perfil en uso':'entrar a mi música'}">
   <span class="profile-avatar-frame"><img src="avatars/${avatar}.png" alt="" loading="eager"><span class="profile-avatar-indicator ${busy?'occupied':'free'}" aria-hidden="true">${busy?'!':'✓'}</span></span>
   <strong>${name}</strong>
   <span class="profile-choice-state">${busy?'En uso en otro equipo':'Disponible para entrar'}</span>
   <span class="profile-choice-arrow" aria-hidden="true">›</span>
  </button>`;
 }).join('')||empty('No hay perfiles','Pide al administrador que configure tus perfiles.');
}
const pageTitle=(label,title,description)=>`<div class="section-intro"><div class="eyebrow">${esc(label)}</div><h1>${esc(title)}</h1><p>${esc(description)}</p></div>`;
const btnMore=(label,act)=>`<button data-act="${act}">${esc(label)} ${icon('chevron')}</button>`;
const section=(title,content,action='',extra='')=>`<section class="section"><div class="section-heading"><h2>${esc(title)}</h2>${action?btnMore(extra||'Ver todas',action):''}</div>${content}</section>`;
const empty=(title,description)=>`<div class="empty">${icon('music')}<b>${esc(title)}</b><span>${esc(description)}</span></div>`;
const badges=()=>`<div class="statline"><div class="stat"><b>${S.favorites.length}</b><span>Tus favoritos</span></div><div class="stat"><b>${S.playlists.length}</b><span>Playlists</span></div><div class="stat"><b>${S.history.length}</b><span>Escuchadas</span></div></div>`;
function horizontal(list){
 if(!list.length)return empty('Tu música comienza aquí','Escucha canciones para personalizar esta sección');
 const id=listKey(list);
 return `<div class="horizontal">${list.slice(0,12).map((t,i)=>`<div class="tile" data-act="play" data-list="${id}" data-i="${i}"><div class="tile-img">${artImg(t,'tile-cover',i>=7)}<div class="tile-caption"><div class="tile-label">${esc(t.title)}</div><div class="tile-desc">${esc(t.artist)}</div></div><button class="tile-play" aria-label="Reproducir">${icon('play')}</button></div></div>`).join('')}</div>`;
}
function tracks(list,opts={}){
 if(!list.length)return empty(opts.emptyTitle||'Nada por aquí todavía',opts.emptyText||'Explora el catálogo y vuelve a intentarlo');
 const id=listKey(list);
 return `<div class="track-list">${list.map((t,i)=>{
  const liked=S.favorites.some(x=>x.provider===t.provider&&x.id===t.id);
  return `<div class="track" data-act="play" data-list="${id}" data-i="${i}"><div class="track-artframe">${artImg(t,'track-cover',i>=9)}</div><div class="track-info"><div class="track-name">${esc(t.title)}</div><div class="track-artist">${esc(t.artist)}${t.album?' · '+esc(t.album):''}</div></div><div class="track-actions"><button class="icon-btn ${liked?'active':''}" data-act="favorite" data-list="${id}" data-i="${i}" aria-label="${liked?'Quitar de':'Agregar a'} favoritos">${icon('heart')}</button><button class="icon-btn" data-act="add-playlist" data-list="${id}" data-i="${i}" aria-label="Agregar a playlist">${icon('plus')}</button>${opts.removable?`<button class="icon-btn" data-act="remove-playlist-track" data-list="${id}" data-i="${i}" aria-label="Quitar de playlist">${icon('close')}</button>`:`<button class="icon-btn track-play" data-act="play" data-list="${id}" data-i="${i}" aria-label="Reproducir">${icon('play')}</button>`}</div></div>`
 }).join('')}</div>`;
}
const GENRES=[
 {name:'Reguetón',subtitle:'Perreo, urbano y hits modernos',emoji:'🔥',accent:'genre-reggaeton'},
 {name:'Salsa',subtitle:'Clásicos bailables y sabor tropical',emoji:'💃',accent:'genre-salsa'},
 {name:'Bachata',subtitle:'Romance, guitarras y sentimiento',emoji:'🎸',accent:'genre-bachata'},
 {name:'Pop latino',subtitle:'Melodías comerciales y actuales',emoji:'🎤',accent:'genre-pop'},
 {name:'Rock',subtitle:'Guitarras, actitud y potencia',emoji:'🤘',accent:'genre-rock'},
 {name:'Electrónica',subtitle:'Beat, energía y fiesta',emoji:'🎧',accent:'genre-electro'},
 {name:'Cumbia',subtitle:'Ritmo para gozar y celebrar',emoji:'🪘',accent:'genre-cumbia'},
 {name:'Música peruana',subtitle:'Raíces, costa, sierra y selva',emoji:'🇵🇪',accent:'genre-peru'}
];
const genreGrid=()=>`<div class="genre-grid">${GENRES.map(g=>`<button class="genre ${g.accent}" data-act="genre" data-query="${esc(g.name)}"><span class="genre-glow"></span><span class="genre-emoji" aria-hidden="true">${g.emoji}</span><span class="genre-copy"><b>${esc(g.name)}</b><small>${esc(g.subtitle)}</small></span></button>`).join('')}</div>`;
const uniqueTracks=list=>{const map=new Map();(list||[]).forEach(t=>{if(t&&t.id)map.set((t.provider||'')+':'+t.id,t)});return [...map.values()]};
const sameTrack=(a,b)=>!!(a&&b&&a.id&&b.id&&a.id===b.id&&(a.provider||'')===(b.provider||''));
const normalize=v=>String(v||'').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g,'').replace(/[^a-z0-9\s]/g,' ').replace(/\s+/g,' ').trim();
const includesLoose=(a,b)=>{const na=normalize(a),nb=normalize(b);return !!na&&!!nb&&(na.includes(nb)||nb.includes(na));};
const allKnown=()=>{const map=new Map();[...S.history,...S.favorites,...S.results,...S.trending,...Object.values(S.artistSearch||{}).flatMap(v=>(v&&v.items)||[])].forEach(t=>{if(t&&t.id)map.set((t.provider||'')+':'+t.id,t)});return [...map.values()]};

const artists=()=>{const map=new Map();allKnown().forEach(t=>{if(!t.artist||t.artist==='Artista no indicado')return;const key=t.artist.toLowerCase().trim();if(!map.has(key))map.set(key,{name:t.artist,artwork:t.artwork,count:0});map.get(key).count++});return [...map.values()].sort((a,b)=>b.count-a.count).slice(0,25)};
const albumGroups=()=>{const map=new Map();allKnown().forEach(t=>{if(!t.album)return;let key=t.artist+'::'+t.album;if(!map.has(key))map.set(key,{artist:t.artist,album:t.album,artwork:t.artwork,year:t.year,tracks:[]});map.get(key).tracks.push(t)});return [...map.values()]};
const recentChips=()=>S.recent.length?`<div class="chips">${S.recent.slice(0,8).map(q=>`<button class="chip" data-act="genre" data-query="${esc(q)}">${icon('clock')} ${esc(q)}</button>`).join('')}</div>`:'';
const artistRows=()=>{
 const ranked=S.chartArtists.length>0;
 const items=ranked?S.chartArtists:artists();
 if(!items.length)return empty('Sin artistas disponibles',S.chartState==='loading'?'Consultando el ranking musical mundial...':'Busca canciones para descubrir artistas disponibles.');
 return items.map((a,i)=>`<div class="artist-card" data-act="artist" data-name="${esc(a.name)}"><img class="artist-avatar" src="${esc(cover(a.image||a.artwork))}" alt="" loading="lazy"><div class="artist-text"><strong>${esc(a.name)}</strong><span>${ranked?'Artista destacado · Ranking mundial':'Explora sus canciones'}</span></div>${icon('chevron')}</div>`).join('');
};
// A search is not the world-wide chart. Only offer artists connected to
// the current query and let the user open a provider-backed paged catalogue.
const artistSearchResults=()=>{
 const query=S.searchTerm.trim();
 if(!query)return empty('Busca un cantante','Escribe el nombre de un artista y pulsa Buscar para explorar sus canciones.');
 if(S.loading)return loading();
 const norm=s=>String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLocaleLowerCase().replace(/\s+/g,' ').trim();
 const clean=s=>String(s||'').replace(/\s+-\s+(?:topic|official artist channel|official)\s*$/i,'').replace(/vevo$/i,'').trim();
 const expected=norm(query);const byName=new Map();
 S.results.forEach(t=>{
  if(!t||!t.artist||t.artist==='Artista no indicado')return;
  const name=clean(t.artist),key=norm(name);
  if(!key||(!key.includes(expected)&&!expected.includes(key)))return;
  if(!byName.has(key))byName.set(key,{name,artwork:t.artworkLarge||t.artwork,number:0});
  byName.get(key).number++;
 });
 const matches=[...byName.values()].sort((a,b)=>b.number-a.number).slice(0,12);
 // If the search provider names uploader channels inconsistently, offer the
 // user's actual query as an explicit lookup, without inventing an artist rank.
 if(!matches.length)matches.push({name:query,artwork:'',number:0});
 return `<div class="section-heading artist-search-heading"><h2>Artistas encontrados</h2><span class="muted">${matches.length} resultado${matches.length===1?'':'s'}</span></div>
 <p class="muted artist-search-help">Abre un artista para buscar sus canciones. Usa «Cargar más canciones» para consultar otras páginas disponibles.</p>
 ${matches.map(a=>`<button class="artist-card search-artist-card" data-act="artist" data-name="${esc(a.name)}">
   <img class="artist-avatar" src="${esc(cover(a.artwork))}" loading="eager" alt="">
   <span class="artist-text"><strong>${esc(a.name)}</strong><span>${a.number?`${a.number} resultado${a.number===1?'':'s'} en esta búsqueda`:'Buscar canciones de este artista'}</span></span>${icon('chevron')}
 </button>`).join('')}`;
};
const albumsHtml=()=>{let items=albumGroups();return items.length?`<div class="horizontal">${items.map(a=>`<div class="tile" data-act="album" data-album="${esc(a.album)}" data-artist="${esc(a.artist)}"><div class="tile-img">${a.tracks.length?artImg(a.tracks[0],'tile-cover',false):`<img src="${esc(cover(a.artwork))}" alt="">`}<div class="tile-caption"><div class="tile-label">${esc(a.album)}</div><div class="tile-desc">${esc(a.artist)}</div></div></div></div>`).join('')}</div>`:empty('Álbumes','El proveedor no ha facilitado datos de álbumes aún')};
const panelBannerUrl=(value)=>{const path=String(value||'');return /^\/assets\/banners\/[a-f0-9]{32}\.(?:webp|jpg|png)$/i.test(path)?'https://onlytvmiusic.onlytvtumbes.com'+path:''};
function bannerHtml(){
 // Respect the banner artwork supplied by the administrator: no generated
 // titles, subtitles, branding or action buttons are painted over the image.
 const b=S.banners.length?S.banners[S.bannerIndex%S.banners.length]:null;
 const img=b?panelBannerUrl(b.image_url):'';
 const dots=S.banners.length>1?`<div class="banner-dots" aria-hidden="true">${S.banners.map((_,i)=>`<span class="${i===S.bannerIndex?'active':''}"></span>`).join('')}</div>`:'';
 return `<section class="home-banner ${img?'with-image':''}" aria-label="Banners de ONLYTV MÚSICA">
  ${img?`<img class="home-banner-picture" src="${esc(img)}" alt="Promoción de ONLYTV MÚSICA" loading="eager" onerror="this.classList.add('hidden');this.parentNode.classList.remove('with-image')">`:''}
  ${dots}
 </section>`;
}

const sectionWithIntro=(name,intro,content,action='',extra='')=>`<section class="section"><div class="section-heading"><h2>${esc(name)}</h2>${action?btnMore(extra||'Ver todas',action):''}</div><p class="home-section-desc">${esc(intro)}</p>${content}</section>`;
function topArtistsHome(){
 if(S.chartState==='loading'&&!S.chartArtists.length)return loading();
 const items=S.chartArtists;
 if(!items.length)return empty('Ranking temporalmente no disponible','No se pudo consultar la clasificación pública. Las canciones de Nuevos temas continúan disponibles.')+`<button class="pill-cta" data-act="refresh-charts" style="margin-top:12px">Reintentar ranking</button>`;
 return `<div class="home-artists">${items.slice(0,12).map((a,i)=>`<button class="home-artist" data-act="artist" data-name="${esc(a.name)}" aria-label="Canciones de ${esc(a.name)}"><img src="${esc(cover(a.image))}" alt="" loading="lazy"><strong>${esc(a.name)}</strong><span>Escuchar canciones ${icon('chevron')}</span></button>`).join('')}</div>`;
}
function trendingHomeHtml(){
 if(S.trending.length)return horizontal(S.trending);
 if(S.trendingLoading||!S.trendingRequested)return loading();
 return `${empty('No se pudieron cargar las tendencias',S.trendingError||'Comprueba la conexión y vuelve a intentarlo.')}
 <button class="pill-cta trend-retry" data-act="retry-trends">Reintentar tendencias</button>`;
}
function home(){
 return `<div class="home-first-section">
 ${sectionWithIntro('Continuar escuchando','Vuelve a tus canciones recientes y retoma la música que te acompaña.',S.history.length?horizontal(S.history):empty('Comienza tu historia musical','Reproduce una canción y aparecerá aquí para continuar escuchándola.'),'history','Ver historial')}
 </div>
 ${bannerHtml()}
 <div class="home-body">
 ${sectionWithIntro('Tendencias','Explora canciones que están destacando en el catálogo musical disponible.',trendingHomeHtml(),'search','Descubrir más')}
 ${sectionWithIntro('Artistas más escuchados','Artistas destacados en un ranking musical mundial, no en tu historial personal. Sus canciones se buscan en Nuevos temas.',topArtistsHome(),'artists','Ver artistas')}
 ${sectionWithIntro('Explora por géneros','¿Qué te provoca escuchar hoy? Elige un estilo y descubre canciones para cada momento.',genreGrid(),'genres','Ver géneros')}
 ${S.favorites.length?sectionWithIntro('Guardadas para ti','Todas esas canciones que marcaste con un corazón.',horizontal(S.favorites),'favorites','Mis favoritos'):''}
 </div>`;
}

function loading(){return `<div class="loading-rows"><div class="skeleton"></div><div class="skeleton"></div><div class="skeleton"></div></div>`}
function searchView(){
 return `${pageTitle('EXPLORAR MÚSICA','Busca lo que te gusta.','Encuentra canciones, artistas y álbumes disponibles.')}
 <form class="search-bar" id="search-form">${icon('search')}<input id="query" type="search" enterkeyhint="search" autocomplete="off" placeholder="Canción, artista o álbum" value="${esc(S.searchTerm)}"><button class="search-submit" type="submit">Buscar</button></form>
 ${S.searchTerm?'':recentChips()}
 <div class="chips">${[['all','Todos'],['songs','Canciones'],['artists','Artistas'],['albums','Álbumes']].map(pair=>`<button class="chip ${S.searchFilter===pair[0]?'active':''}" data-act="filter" data-filter="${pair[0]}">${pair[1]}</button>`).join('')}</div>
 ${S.loading?loading():searchResultsHtml()}
 ${!S.searchTerm?section('Géneros para descubrir',genreGrid()):''}`;
}
function searchResultsHtml(){
 const list=S.results.length?S.results:S.searchTerm?[]:S.trending;
 if(!S.searchTerm&&!list.length)return empty('Empieza a explorar','Busca una canción o artista para descubrir resultados reales');
 if(S.searchFilter==='artists')return artistSearchResults();
 if(S.searchFilter==='albums')return albumsHtml();
 if(!list.length)return empty('Sin resultados','No hay canciones disponibles para la búsqueda actual');
 return `<div class="section-heading" style="margin-top:12px"><h2>${S.searchTerm?'Resultados':'Música para descubrir'}</h2><span class="muted">${list.length} canciones</span></div>${tracks(list)}`;
}

// Playlists: premium layout without changing the existing native library/storage methods.
const playlistCover=(variant=0,extra='')=>`<div class="ot-playlist-cover ot-playlist-cover--${variant%4} ${extra}"><span class="ot-playlist-cover-ring"></span><span class="ot-playlist-cover-glow"></span>${icon('music')}</div>`;
function playlistCard(p,i){
 const size=Math.max(0,Number(p.size)||0);
 return `<article class="ot-playlist-card">
  <button type="button" class="ot-playlist-open" data-act="open-playlist" data-id="${esc(p.id)}" aria-label="Abrir ${esc(p.name)}">
   ${playlistCover(i)}
   <span class="ot-playlist-card-copy"><span class="ot-playlist-tag">MI COLECCIÓN</span><strong>${esc(p.name)}</strong><span class="ot-playlist-subtitle">${size} ${size===1?'canción':'canciones'} <span class="ot-playlist-dot">·</span> Lista personal</span></span>
   ${icon('chevron','ot-playlist-arrow')}
  </button>
  <button type="button" class="ot-playlist-more" data-act="playlist-menu" data-id="${esc(p.id)}" aria-label="Administrar ${esc(p.name)}">${icon('more')}</button>
 </article>`;
}
function playlistsView(){
 const count=S.playlists.length;
 const songs=S.playlists.reduce((sum,p)=>sum+Math.max(0,Number(p.size)||0),0);
 return `<section class="ot-playlists-page">
  ${pageTitle('TU MÚSICA, TUS REGLAS','Tus playlists.','Cada momento merece su propia banda sonora. Organiza tu música como más te guste.')}
  <div class="ot-playlists-hero">
   <span class="ot-playlists-light ot-playlists-light--one"></span><span class="ot-playlists-light ot-playlists-light--two"></span>
   <div class="ot-playlists-hero-top"><span class="ot-playlists-kicker">${icon('sparkles')} TU COLECCIÓN PERSONAL</span>${playlistCover(0,'ot-playlists-hero-mark')}</div>
   <h2>Tu música.<br><span>A tu manera.</span></h2>
   <p>Reúne tus canciones favoritas, crea momentos y lleva tus listas contigo.</p>
   <button type="button" class="ot-create-playlist" data-act="new-playlist">${icon('plus')} Crear nueva playlist ${icon('chevron')}</button>
  </div>
  <div class="ot-playlists-summary"><div><strong>${count}</strong><span>${count===1?'Playlist creada':'Playlists creadas'}</span></div><span class="ot-playlists-summary-line"></span><div><strong>${songs}</strong><span>${songs===1?'Canción guardada':'Canciones guardadas'}</span></div></div>
  <div class="ot-playlists-list-heading"><div><span class="eyebrow">TU BIBLIOTECA</span><h3>Mis colecciones</h3></div><span>${count} ${count===1?'lista':'listas'}</span></div>
  ${count?`<div class="ot-playlists-grid">${S.playlists.map(playlistCard).join('')}</div>`:`<div class="ot-playlists-empty">${playlistCover(1)}<h3>Tu primera playlist comienza aquí</h3><p>Crea una lista y guarda las canciones que quieras escuchar una y otra vez.</p><button type="button" data-act="new-playlist">${icon('plus')} Crear mi primera playlist</button></div>`}
 </section>`;
}
const historyKey=t=>`${t.provider}:${t.id}`;
function historySelectionItems(){return `<div class="ot-history-selection-list">${S.history.map((t,i)=>{
 const key=historyKey(t),checked=S.historySelected.has(key);
 return `<label class="ot-history-song ${checked?'is-selected':''}"><input class="ot-history-check" type="checkbox" data-history-key="${esc(key)}" ${checked?'checked':''} aria-label="Seleccionar ${esc(t.title||'canción')}">
 <span class="ot-history-check-art" aria-hidden="true">${artImg(t,'ot-history-art')}</span>
 <span class="ot-history-song-copy"><strong>${esc(t.title||'Canción')}</strong><small>${esc(t.artist||'Artista')}</small></span><span class="ot-history-song-mark">${icon('check')}</span></label>`;
 }).join('')}</div>`;}
function historyToolbar(){
 if(!S.history.length)return '';
 const count=S.historySelected.size,total=S.history.length,all=count===total;
 return `<section class="ot-history-manager ${S.historySelecting?'is-editing':''}" aria-label="Administrar historial">
  ${S.historySelecting?`<div class="ot-history-manager-top"><span class="ot-history-manager-kicker">MODO SELECCIÓN</span><button type="button" class="ot-history-cancel" data-act="history-cancel">${icon('close')} Cancelar</button></div>
    <div class="ot-history-manager-main"><div><strong>${count} ${count===1?'seleccionada':'seleccionadas'}</strong><small>de ${total} ${total===1?'canción':'canciones'} en tu historial</small></div><span class="ot-history-count">${count}/${total}</span></div>
    <div class="ot-history-buttons"><button type="button" class="ot-history-select-all" data-act="history-toggle-all">${icon(all?'close':'check')} ${all?'Deseleccionar':'Seleccionar todo'}</button>
    <button type="button" class="ot-history-remove" data-act="history-delete-selected" ${count?'':'disabled'}>${icon('close')} Eliminar ${count?'('+count+')':''}</button></div>`:
   `<div class="ot-history-manager-main"><div><strong>Organiza tus escuchas</strong><small>${total} ${total===1?'canción guardada':'canciones guardadas'} en este celular</small></div><button type="button" class="ot-history-edit" data-act="history-edit">${icon('check')} Seleccionar</button></div>
    <button type="button" class="ot-history-delete-all" data-act="clear-history">${icon('close')} Eliminar todo el historial</button>`}
 </section>`;
}
function libraryPage(which){let fav=which==='favorites';return `${pageTitle('TU BIBLIOTECA',fav?'Canciones favoritas.':'Tu historial.',fav?'Las canciones que guardaste para repetir.':'Todo lo que has escuchado recientemente.')}
 ${!fav?`${historyToolbar()}${S.history.length?`<div class="ot-history-security-note">${icon('check')} <span>Los cambios se aplican <b>solo a este celular.</b> Tu copia del servidor se conserva.</span></div>`:''}`:''}
 <div class="ot-history-body">${!fav&&S.historySelecting?historySelectionItems():tracks(fav?S.favorites:S.history,{emptyTitle:fav?'Aún no tienes favoritos':'Todavía no has escuchado canciones',emptyText:'Elige una canción y regresa aquí.'})}</div>`;}
function detailView(){let d=S.detail;if(!d)return home();
 if(d.type==='playlist'){
  const pl=S.playlists.find(x=>x.id===d.id),title=pl?pl.name:'Playlist';let contents=parse(native('playlistTracks',d.id),[]);
  return `<section class="ot-playlist-detail">
   <div class="ot-playlist-detail-top"><button type="button" data-act="playlists" aria-label="Volver a mis playlists">${icon('back')}</button><span>MI BIBLIOTECA / PLAYLISTS</span><button type="button" data-act="playlist-menu" data-id="${esc(d.id)}" aria-label="Administrar playlist">${icon('more')}</button></div>
   <div class="ot-playlist-detail-hero">${playlistCover(S.playlists.findIndex(x=>x.id===d.id))}
     <div class="ot-playlist-detail-info"><span class="ot-playlist-tag">MI PLAYLIST</span><h1>${esc(title)}</h1><p>${contents.length} ${contents.length===1?'canción':'canciones'} · Tu selección personal</p></div>
   </div>
   <div class="ot-playlist-detail-actions"><button type="button" class="ot-create-playlist" data-act="playlist-play-all" data-id="${esc(d.id)}" ${contents.length?'':'disabled'}>${icon('play')} Reproducir playlist</button><button type="button" class="ot-playlist-add-song" data-act="discover">${icon('plus')} Añadir canciones</button></div>
   <div class="ot-playlist-tracks-heading"><h2>Canciones de esta lista</h2><span>${contents.length}</span></div>
   ${tracks(contents,{removable:true,emptyTitle:'Esta playlist está vacía',emptyText:'Pulsa «Añadir canciones» para encontrar tus primeros temas.'})}
  </section>`;
 }
 if(d.type==='artist'){
  const state=S.artistSearch[d.name]||{items:[],page:0,loading:false,hasMore:true,error:''};
  const a=S.chartArtists.find(x=>normalize(x.name)===normalize(d.name))||artists().find(x=>normalize(x.name)===normalize(d.name));
  const info=S.artistInfo[d.name]||{};
  const trackWithArt=state.items.find(x=>cover(x.artworkLarge||x.artwork)!=='icon.png');
  const artistPhoto=cover(info.image||(a&&(a.image||a.artwork))||(trackWithArt&&(trackWithArt.artworkLarge||trackWithArt.artwork)));
  const hasPhoto=artistPhoto!=='icon.png';
  const followed=S.followed.some(x=>normalize(x)===normalize(d.name));
  const rank=a&&Number(a.rank)>0?Number(a.rank):0;
  const chartLabel=rank?`Puesto ${rank} · Ranking mundial de artistas`:info.fans?`${new Intl.NumberFormat('es-PE').format(info.fans)} seguidores en Deezer`:'Artista · Catálogo Nuevos temas';
  const results=state.items.length?tracks(state.items):state.loading?loading():empty('Sin canciones encontradas','Prueba otra búsqueda o actualiza el perfil.');
  const controls=state.loading?`<p class="muted artist-search-status">Buscando más canciones de ${esc(d.name)}...</p>`:
   state.hasMore?`<button class="pill-cta artist-load-more" data-act="more-artist">${icon('plus')} ${state.items.length?'Cargar más canciones':'Buscar canciones'}</button>`:
   `<p class="muted artist-search-status">${esc(state.error||'Has llegado al final de los resultados disponibles.')}</p>`;
  return `<div class="artist-profile">
   <div class="backline artist-backline"><button data-act="artists" aria-label="Volver">${icon('back')}</button><h3>Artista</h3></div>
   <div class="artist-feature-card">
    <div class="artist-feature-photo ${hasPhoto?'':'artist-photo-placeholder'}" role="img" aria-label="Imagen de ${esc(d.name)}" style="background-image:url('${esc(artistPhoto)}')"></div>
    <div class="artist-feature-photo-shade"></div>
    <div class="artist-feature-content"><span class="artist-verified-label">${rank?'EN EL RANKING MUNDIAL':'PERFIL DEL ARTISTA'}</span><h1>${esc(d.name)}</h1></div>
   </div>
   <div class="artist-about-card"><div class="artist-about-meta"><div class="artist-about-heading"><span class="eyebrow">ACERCA DEL ARTISTA</span><h2>${esc(d.name)}</h2><p>${esc(chartLabel)}</p></div><button class="artist-follow-btn ${followed?'is-followed':''}" data-act="follow" data-name="${esc(d.name)}">${icon(followed?'check':'plus')} ${followed?'Siguiendo':'Seguir'}</button></div>
   <p class="artist-about-summary">Explora las canciones de ${esc(d.name)} disponibles en ONLYTV MÚSICA. Encuentra tus favoritas y añádelas a tus playlists.${info.albums?` <span class="artist-about-source">${new Intl.NumberFormat('es-PE').format(info.albums)} álbumes registrados en Deezer.</span>`:''}</p>
   <div class="artist-availability">${icon('music')} ${state.items.length?state.items.length+' canciones encontradas':'Buscando canciones disponibles'}${state.hasMore?' · Más por descubrir':''}</div></div>
   ${section('Canciones de '+d.name,results)}${controls}
  </div>`;
 }
 if(d.type==='album'){
  const list=allKnown().filter(t=>t.artist===d.artist&&t.album===d.album),t=list[0];
  return `<div class="backline"><button data-act="albums">${icon('back')}</button><h3>Álbum</h3></div><div class="album-lead"><img src="${esc(cover(t&&t.artwork))}" alt=""><h2>${esc(d.album)}</h2><p>${esc(d.artist)} ${t&&t.year?'· '+esc(t.year):''}</p></div>${tracks(list)}`;
 }
 return home();
}
function artistsView(){return `${pageTitle('RANKING MUNDIAL','Artistas más escuchados.','Esta lista utiliza un ranking musical público. Al abrir un artista puedes explorar sus canciones desde Nuevos temas.')}${artistRows()}`}
function albumsView(){return `${pageTitle('EXPLORAR','Álbumes.','Se muestran solo los álbumes identificados por los proveedores.')}${albumsHtml()}`}
function genresView(){return `${pageTitle('DESCUBRIMIENTOS','Géneros musicales.','Encuentra nuevos sonidos a través del buscador.')}${section('Elige tu ritmo',genreGrid())}`}
function queueView(){let list=parse(native('queue'),S.playback.queue||[]);return `${pageTitle('EN REPRODUCCIÓN','Tu cola musical.','Las canciones que siguen en tu lista de reproducción.')}${tracks(list,{emptyTitle:'Cola vacía',emptyText:'Busca canciones y comienza una sesión de música.'})}`}
function profileView(){const selected=S.accountProfiles.find(p=>Number(p.id)===S.activeProfileId)||{};
 const avatar=/^avatar[1-8]$/.test(selected.avatar||'')?selected.avatar:'avatar1';
 const expiry=S.expiresAt?formatPlanDate(S.expiresAt):'Consulta tu plan';
 const activated=S.startsOn?formatPlanDate(S.startsOn):'Consulta tu plan';
 return `<section class="ot-account-page">${pageTitle('TU CUENTA','Mi espacio.','Gestiona tu perfil, protege tu biblioteca y consulta tu servicio.')}
 <div class="account-profile"><img src="avatars/${avatar}.png" alt="Avatar ${esc(selected.name||'Principal')}"><div><strong>${esc(selected.name||S.username)}</strong><span>${esc(S.username)} · ${S.accountType==='familiar'?'Plan familiar':'Plan individual'}${S.isDemo?' · DEMO':''}</span></div></div>
 <div class="account-plan-dates"><div>${icon('check')}<span>Activación del servicio<strong>${esc(activated)}</strong></span></div><div>${icon('clock')}<span>Vencimiento del servicio<strong>${esc(expiry)}</strong></span></div></div>
 <div class="notice">${icon('music')} ${S.isDemo?'Esta cuenta de prueba no guarda datos permanentes.':'Tus favoritos, historial y playlists se respaldan en tu cuenta.'}</div>
 ${!S.isDemo?`<div class="notice">${icon('check')} Respaldo: <b>${S.librarySyncedAt?new Date(S.librarySyncedAt).toLocaleString('es-PE'):'Pendiente de sincronizar'}</b></div>`:''}
 <div class="ot-account-action-group">
 ${S.accountType==='familiar'?`<div class="profile-lease-note">Tu perfil permanece activo en este dispositivo hasta cerrar sesión.</div>`:''}
 ${!S.isDemo?`<button class="modal-option" data-act="sync-library">${icon('check')} Sincronizar mi biblioteca ${icon('chevron')}</button>
 <button class="modal-option" data-act="delete-library">${icon('close')} Eliminar datos de mi biblioteca ${icon('chevron')}</button>`:''}
 <button class="modal-option" data-act="check-app-update">${icon('check')} Actualizar aplicación ${icon('chevron')}</button>
 <button class="modal-option" data-act="verify">${icon('check')} Comprobar mi sesión ${icon('chevron')}</button>
 <button class="modal-option ot-logout-action" data-act="logout">${icon('logout')} Cerrar sesión ${icon('chevron')}</button>
 </div>
 <section class="ot-about-card" aria-label="Quiénes somos">
  <div class="ot-about-gradient" aria-hidden="true"></div>
  <div class="ot-about-heading"><span class="ot-about-badge">${icon('sparkles')} CONÓCENOS</span><img src="login_logo_2026.png" alt="OnlyTVMiusic"></div>
  <h2>Quiénes somos<span class="ot-about-period">.</span></h2>
  <p><strong>OnlyTVMiusic</strong> nace con una idea sencilla: hacer que la música forme parte de cada momento, con una experiencia cómoda, moderna y cercana.</p>
  <p>Trabajamos para seguir mejorando nuestro servicio y buscar alternativas que ayuden a las personas a acceder a experiencias de entretenimiento <strong>al alcance de su bolsillo</strong>, con atención clara y un trato humano.</p>
  <div class="ot-about-values"><span>${icon('headphones')} Música a tu ritmo</span><span>${icon('heart')} Hecho para disfrutar</span></div>
  <button type="button" class="ot-about-support" data-act="support-whatsapp" aria-label="Contactar a soporte técnico por WhatsApp al +51 986 385 469"><span class="ot-about-support-icon">${icon('headphones')}</span><span class="ot-about-support-copy"><span>¿Necesitas ayuda?</span><strong>Soporte técnico</strong><small>WhatsApp: +51 986 385 469</small></span><span class="ot-about-support-arrow">${icon('chevron')}</span></button>
 </section>
 </section>`;
}
function render(){
 if(!S.loggedIn)return;
 S.listMap={};S.listId=0;
 const views={home,search:searchView,favorites:()=>libraryPage('favorites'),history:()=>libraryPage('history'),playlists:playlistsView,detail:detailView,artists:artistsView,albums:albumsView,genres:genresView,queue:queueView,profile:profileView};
 $('shell').classList.toggle('home-view',S.page==='home');
 $('content').innerHTML=(!S.sessionReady?'<div class="notice" role="status">'+icon('clock')+' Comprobando tu acceso al servicio. Tu biblioteca sigue disponible.</div>':'')+(views[S.page]||home)();
 document.querySelectorAll('.nav-item').forEach(el=>el.classList.toggle('active',el.dataset.page===S.page|| (S.page==='detail'&&el.dataset.page==='playlists'&&S.detail&&S.detail.type==='playlist')));
}
function switchPage(page,detail=null){S.page=page;S.detail=detail;if(page==='detail'&&detail&&detail.type==='artist'){ensureArtistSearch(detail.name);ensureArtistProfile(detail.name)}render();window.scrollTo({top:0,behavior:'auto'});if(page==='home'&&S.loggedIn&&Date.now()-S.bannerLoadedAt>300000){S.bannerLoadedAt=Date.now();native('loadBanners')}if(page==='search'){let input=$('query');if(input)input.focus()}}
function loadTrending(force){
 if(!S.loggedIn||!S.sessionReady||S.trendingLoading)return;
 if(S.trendingRequested&&!force)return;
 S.trendingRequested=true;S.trendingLoading=true;S.trendingError='';
 // This request is entirely separate from typed queries and search filters.
 S.trendingRequestId=native('search','',true)||0;
 if(S.page==='home')render();
}
function startSearch(query,trending){
 if(!S.loggedIn||!S.sessionReady)return;
 if(trending){loadTrending(false);return;}
 S.loading=true;
 S.searchTerm=(query||'').trim();S.page='search';S.searchFilter='all';native('rememberSearch',S.searchTerm);
 render();
 S.requestId=native('search',query||'',false)||0;
}
function ensureArtistProfile(name){
 if(!name||S.artistInfo[name]||S.artistInfoPending[name]||!S.sessionReady)return;
 S.artistInfoPending[name]=true;
 native('loadArtistInfo',name);
}
function ensureArtistSearch(name){
 if(!name)return;
 if(!S.artistSearch[name])S.artistSearch[name]={items:[],page:0,loading:false,hasMore:true,error:''};
 const state=S.artistSearch[name];
 if(!state.items.length&&!state.loading&&state.hasMore)loadArtistPage(name);
}
function loadArtistPage(name){
 if(!S.sessionReady){toast('Conectando con el servicio...');return}
 const state=S.artistSearch[name];if(!state||state.loading||!state.hasMore)return;
 state.loading=true;state.error='';render();native('searchArtist',name,state.page);
}
let queueCloseTimer=0;
function closePlayerQueue(){
 if(!S.queueOpen)return;
 S.queueOpen=false;
 const sheet=$('player-queue-sheet');
 sheet.classList.add('is-closing');
 clearTimeout(queueCloseTimer);
 queueCloseTimer=setTimeout(()=>{if(!S.queueOpen){sheet.classList.add('hidden');sheet.classList.remove('is-closing')}},240);
}
function renderPlayerQueue(){
 if(!S.queueOpen)return;
 const list=parse(native('queue'),[]);
 const p=S.playback||{};
 const t=playerTrack();
 const ctx=S.playContext;
 const spec=t?playerSuggestionSpec(t):{list:[],title:''};
 const key=list.map(x=>x&&x.id||'').join('|')+'@'+p.queueIndex+'#'+(t&&t.id||'')+'!'+spec.list.map(x=>x.id).join('|');
 if(S.queueLastKey===key)return;
 S.queueLastKey=key;
 $('player-queue-items').innerHTML=(list.length?`<div class="queue-list-label">EN LA COLA · ${list.length} CANCIONES</div>`+list.map((item,i)=>`<button class="player-queue-item ${i===p.queueIndex?'is-current':''}" data-act="queue-play-index" data-i="${i}">
 <span class="player-queue-number">${i+1}</span><span class="player-queue-art">${artImg(item,'player-queue-cover',i>=12)}</span>
 <span class="player-queue-text"><strong>${esc(item.title)}</strong><small>${esc(item.artist)}</small></span>
 <span class="player-queue-marker">${i===p.queueIndex?icon('volume'):icon('play')}</span></button>`).join('')
 :empty('Tu cola está vacía','Busca una canción para comenzar.'))+
 (spec.list.length?`<div class="queue-list-label queue-related-label">${esc(spec.eyebrow)} · ${esc(spec.title)}</div>`+
 `<div class="queue-related-list">${spec.list.map((item,i)=>`<button class="player-queue-item queue-related-item" data-act="queue-related-play" data-i="${i}">
 <span class="player-queue-art">${artImg(item,'player-queue-cover',i>=7)}</span>
 <span class="player-queue-text"><strong>${esc(item.title)}</strong><small>${esc(item.artist)}</small></span>
 <span class="player-queue-marker">${icon('play')}</span></button>`).join('')}</div>`:'');
 S.playerSuggestions=spec.list;
}
function openPlayerQueue(){
 if(!S.playerOpen)return;
 clearTimeout(queueCloseTimer);
 S.queueOpen=true;S.queueLastKey='';
 $('player-queue-sheet').classList.remove('hidden','is-closing');
 renderPlayerQueue();
 toast('Lista de canciones');
}
function closePlayer(){closePlayerQueue();S.playerOpen=false;$('player-screen').classList.add('hidden');document.body.classList.remove('player-active')}
function currentOpen(){S.playerOpen=true;$('player-screen').classList.remove('hidden');document.body.classList.add('player-active');$('player-screen').scrollTop=0;renderPlayer()}
function refreshLibrary(){const d=parse(native('bootstrap'),{});S.favorites=d.favorites||[];S.history=d.history||[];S.playlists=d.playlists||[];S.followed=d.followed||[];S.recent=d.recent||[]}
function derivePlayContext(list,index){
 const selected=(list||[])[index]||null;
 const ctx={kind:'selection',sourcePage:S.page,query:S.searchTerm||'',filter:S.searchFilter||'all',list:Array.isArray(list)?list.slice():[],artist:selected&&selected.artist?selected.artist:'',album:selected&&selected.album?selected.album:'',title:'Sigue escuchando'};
 if(S.page==='detail'&&S.detail){
  if(S.detail.type==='artist'){ctx.kind='artist';ctx.artist=S.detail.name||ctx.artist;ctx.title=`Más canciones de ${ctx.artist||'este artista'}`;}
  else if(S.detail.type==='album'){ctx.kind='album';ctx.album=S.detail.album||ctx.album;ctx.artist=S.detail.artist||ctx.artist;ctx.title=`Más del álbum ${ctx.album||''}`.trim();}
  else if(S.detail.type==='playlist'){ctx.kind='playlist';ctx.title=`Más de ${S.playlists.find(x=>x.id===S.detail.id)?.name||'esta playlist'}`;}
 }else if(S.page==='favorites'){ctx.kind='favorites';ctx.title='Más de tus favoritos';}
 else if(S.page==='history'){ctx.kind='history';ctx.title='Continúa escuchando';}
 else if(S.page==='queue'){ctx.kind='queue';ctx.title='Cola de reproducción';}
 else if(S.page==='search'&&S.searchTerm){ctx.kind='search';ctx.title=`Recomendadas para ${selected&&selected.title?selected.title:'tu búsqueda'}`;}
 return ctx;
}
function similarTracks(track,ctx){
 const source=(ctx&&ctx.list)||[];
 const withoutCurrent=source.filter(x=>!sameTrack(x,track));
 if(ctx&&['artist','album','playlist','favorites','history','queue'].includes(ctx.kind)&&withoutCurrent.length)return uniqueTracks(withoutCurrent);
 if(ctx&&ctx.kind==='artist'&&ctx.artist){
  const pool=allKnown().filter(x=>!sameTrack(x,track)&&includesLoose(x.artist,ctx.artist));
  return uniqueTracks([...withoutCurrent,...pool]);
 }
 const pool=allKnown().filter(x=>!sameTrack(x,track));
 const targetArtist=normalize((ctx&&ctx.artist)||track.artist);
 const targetAlbum=normalize((ctx&&ctx.album)||track.album);
 const targetGenre=normalize(track.genre);
 const query=normalize((ctx&&ctx.query)||track.title);
 return pool.map(item=>{
   let score=0;
   if(targetArtist&&normalize(item.artist)===targetArtist)score+=12;
   else if(targetArtist&&includesLoose(item.artist,targetArtist))score+=8;
   if(targetAlbum&&normalize(item.album)===targetAlbum)score+=7;
   if(targetGenre&&normalize(item.genre)===targetGenre)score+=4;
   if(query&&includesLoose(item.title,query))score+=3;
   if(query&&includesLoose(item.artist,query))score+=2;
   if(source.some(x=>sameTrack(x,item)))score+=2;
   return {item,score};
 }).filter(x=>x.score>0).sort((a,b)=>b.score-a.score).map(x=>x.item);
}
function playerSuggestionSpec(track){
 const ctx=S.playContext||{kind:'selection',list:parse(native('queue'),S.playback.queue||[]),title:'Sigue escuchando'};
 let list=[];let eyebrow='SIGUE ESCUCHANDO';let title=ctx.title||'Sigue escuchando';
 if(ctx.kind==='artist'){
  list=uniqueTracks([...(ctx.list||[]).filter(x=>!sameTrack(x,track)),...allKnown().filter(x=>!sameTrack(x,track)&&includesLoose(x.artist,ctx.artist||track.artist))]);
  eyebrow='DEL ARTISTA';title=`Más canciones de ${ctx.artist||track.artist||'este artista'}`;
 }else if(ctx.kind==='album'){
  list=uniqueTracks([...(ctx.list||[]).filter(x=>!sameTrack(x,track)),...allKnown().filter(x=>!sameTrack(x,track)&&normalize(x.album)===normalize(ctx.album||track.album)&&normalize(x.artist)===normalize(ctx.artist||track.artist))]);
  eyebrow='DEL ÁLBUM';title=ctx.album?`Más del álbum ${ctx.album}`:'Más canciones del álbum';
 }else if(ctx.kind==='search'){
  list=similarTracks(track,ctx);eyebrow='RECOMENDADAS';title=`Similares a ${track.title||'esta canción'}`;
 }else{
  list=similarTracks(track,ctx);eyebrow=(ctx.kind==='playlist'?'PLAYLIST ACTUAL':'SIGUE ESCUCHANDO');
 }
 list=uniqueTracks(list).filter(x=>!sameTrack(x,track)).slice(0,10);
 return {list,eyebrow,title};
}
function playerRecommendationsHtml(data){
 if(!data||!data.list||!data.list.length)return '';
 const id=listKey(data.list);
 return `<section class="player-recommend-block"><div class="player-recommend-head"><div class="eyebrow">${esc(data.eyebrow)}</div><h3>${esc(data.title)}</h3></div><div class="player-recommend-list">${data.list.map((t,i)=>`<div class="player-recommend-item" data-act="play" data-list="${id}" data-i="${i}"><div class="player-recommend-art">${artImg(t,'player-recommend-cover',i>3)}</div><div class="player-recommend-copy"><strong>${esc(t.title)}</strong><span>${esc(t.artist)}${t.album?' · '+esc(t.album):''}</span></div><button class="player-recommend-play" data-act="play" data-list="${id}" data-i="${i}" aria-label="Reproducir">${icon('play')}</button></div>`).join('')}</div></section>`;
}
function playFrom(list,index){if(!S.sessionReady){toast('Conectando con tu cuenta. Vuelve a intentar en unos instantes.');return}if(!list||!list.length)return;S.playContext=derivePlayContext(list,index);native('play',JSON.stringify(list),index);S.playback={...S.playback,track:list[index],title:list[index].title,artist:list[index].artist,loading:true,phase:'Resolviendo la fuente musical'};currentOpen()}
function toggle(){const wasPlaying=!!S.playback.playing;native('command',wasPlaying?'PAUSE':'RESUME',0);S.playback.playing=!wasPlaying;renderPlayer();toast(wasPlaying?'Pausa solicitada':'Reproducción solicitada')}
function updateMini(){let p=S.playback,t=p.track&&p.track.id?p.track:null;
 $('mini').classList.toggle('hidden',!t||!S.loggedIn);
 if(!t)return;
 $('mini-title').textContent=t.title||'Reproduciendo';$('mini-artist').textContent=p.loading?(p.phase||'Cargando audio...'):(p.error||t.artist||'');
 const miniImage=$('mini-cover'),newMini=highArt(t);
 if(miniImage.dataset.lastUrl!==newMini){
   miniImage.dataset.lastUrl=newMini;frameArtwork(miniImage,newMini);miniImage.dataset.hq=youtubeHq(t);
   miniImage.dataset.fallback=fallbackArt(t);miniImage.dataset.artStage='source';
   miniImage.onerror=()=>artworkFallback(miniImage);
   miniImage.onload=()=>{frameArtwork(miniImage,miniImage.currentSrc||miniImage.src);if(miniImage.naturalWidth>0&&miniImage.naturalWidth<180)artworkFallback(miniImage)};
   miniImage.src=newMini;
 }
 $('mini-play-icon').setAttribute('href',p.playing?'#i-pause':'#i-play');
 let ratio=(p.duration>0)?Math.max(0,Math.min(100,p.position/p.duration*100)):0;
 $('mini-progress').style.width=ratio+'%';
}
function renderPlayer(){
 updateMini();let p=S.playback,t=p.track&&p.track.id?p.track:null;
 if(!t)return;
 const largeImage=$('big-cover'),newLarge=highArt(t,true);
 if(largeImage.dataset.lastUrl!==newLarge){
   largeImage.dataset.lastUrl=newLarge;
   frameArtwork(largeImage,newLarge);
   largeImage.dataset.hq=youtubeHq(t);
   largeImage.dataset.fallback=fallbackArt(t);
   largeImage.dataset.artStage='source';
   largeImage.onerror=()=>artworkFallback(largeImage);
   largeImage.onload=()=>{
     frameArtwork(largeImage,largeImage.currentSrc||largeImage.src);
     if(largeImage.naturalWidth>0&&largeImage.naturalWidth<300)artworkFallback(largeImage);
   };
   largeImage.src=newLarge;
 }
 // Some videos expose a true 1280px image; others return a tiny 120px
 // placeholder for maxresdefault. Only switch when its decoded size is HD.
 const fullId=ytVideoId(t);
 if(fullId && newLarge===youtubeHq(t) && largeImage.dataset.maxresTried!==fullId){
   largeImage.dataset.maxresTried=fullId;
   const probe=new Image();
   probe.onload=()=>{
     if(largeImage.dataset.lastUrl===newLarge && probe.naturalWidth>=640 && probe.naturalHeight>=360){
       largeImage.src=probe.src;
     }
   };
   probe.onerror=()=>{};
   probe.src=`https://i.ytimg.com/vi/${fullId}/maxresdefault.jpg`;
 }
 $('big-title').textContent=t.title||'Tu música';$('big-artist').textContent=t.artist||'';
 $('main-play-icon').setAttribute('href',p.playing?'#i-pause':'#i-play');
 $('elapsed').textContent=fmt(p.position);$('duration').textContent=fmt(p.duration);
 if(!S.seekHolding){$('seek').max=String(Math.max(100,p.duration||0));$('seek').value=String(p.position||0)}
 $('player-phase').textContent=p.loading?
  ((p.phase||'Preparando audio...')+((p.startupMs||0)>0?` · ${Math.floor(p.startupMs/1000)} s`:'')):
  (p.error||((p.resolveMs||p.prepareMs)?`Fuente ${Math.round((p.resolveMs||0)/100)/10}s · Preparación ${Math.round((p.prepareMs||0)/100)/10}s · Total ${Math.round((p.startupMs||0)/100)/10}s`:''));
 $('shuffle-btn').classList.toggle('active',!!p.shuffle);
 const repeatMode=Number(p.repeat)||0;
 $('repeat-btn').classList.toggle('active',repeatMode!==0);
 $('repeat-btn').classList.toggle('repeat-one',repeatMode===2);
 $('repeat-btn').setAttribute('aria-pressed',repeatMode===0?'false':'true');
 $('repeat-btn').setAttribute('aria-label',repeatMode===0?'Repetición desactivada':repeatMode===1?'Repetir toda la cola':'Repetir la canción actual');
 $('player-heart').classList.toggle('active',S.favorites.some(x=>x.provider===t.provider&&x.id===t.id));
 if(S.queueOpen)renderPlayerQueue();
}
const toast=(text)=>{let el=$('toast');el.textContent=text;el.classList.remove('hidden');clearTimeout(toast._timer);toast._timer=setTimeout(()=>el.classList.add('hidden'),3000)};
const closeModal=()=>{if(S.libraryOperationBusy)return;$('overlay').classList.add('hidden');$('overlay').classList.remove('premium-popup');$('modal').classList.remove('premium-style');$('modal').innerHTML=''};
function modal(title,body,buttons){
 let el=$('modal');el.innerHTML=`<h3>${esc(title)}</h3>${body}<div class="modal-actions">${buttons.map(b=>`<button class="${b.danger?'danger':b.accent?'accent':''}" data-modal="${esc(b.id)}">${esc(b.text)}</button>`).join('')}</div>`;
 $('overlay').classList.remove('hidden');
 modal.buttons={};buttons.forEach(b=>modal.buttons[b.id]=b.act);
}
/** Premium floating dialogs share the existing accessible overlay and real native callbacks. */
function premiumModal(title,body,buttons){
 modal(title,body,buttons);
 $('overlay').classList.add('premium-popup');$('modal').classList.add('premium-style');
}
function shareMusicOptions(){
 const t=playerTrack();if(!t){toast('Selecciona una canción primero');return;}
 const link=native('shareLink')||'';
 if(!link){toast('No está disponible el enlace directo para esta canción');return;}
 premiumModal('Compartir mi canción',`<div class="ot-share-modal">
  <div class="ot-share-hero">
   <img class="ot-share-ambient" src="${esc(highArt(t,true))}" alt="" aria-hidden="true">
   <div class="ot-share-glow"></div>
   <img src="login_logo_2026.png" alt="OnlyTVMiusic · Tu música siempre contigo" class="ot-share-brand">
   <span class="ot-share-chip">${icon('headphones')} Estoy escuchando en OnlyTVMiusic</span>
   <div class="ot-share-song"><img src="${esc(highArt(t,true))}" alt="Portada de la canción"><div><strong>${esc(t.title)}</strong><small>${esc(t.artist)}</small></div></div>
   <div class="ot-share-wave"><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i></div>
   <span class="ot-share-footer">Escúchalo ahora en <b>OnlyTVMiusic</b></span>
  </div>
  <p class="ot-share-caption">Elige cómo deseas compartir. La tarjeta usa la portada de la canción; el enlace abre su reproductor después de verificar la cuenta.</p>
  <div class="ot-share-choices">
   <button data-act="share-card-chat">${icon('share')}<span><b>Compartir en chats</b><small>Imagen vertical · Enlace directo</small></span>${icon('chevron')}</button>
   <button data-act="share-card-status">${icon('disc')}<span><b>Estado de WhatsApp</b><small>Imagen 1080 × 1920</small></span>${icon('chevron')}</button>
   <button data-act="share-link-text">${icon('share')}<span><b>Enviar solo enlace</b><small>Enlace pulsable en chats</small></span>${icon('chevron')}</button>
   <button data-act="share-copy-link">${icon('check')}<span><b>Copiar enlace directo</b><small>Pegar en mensajes o estados</small></span>${icon('chevron')}</button>
  </div>
  <p class="ot-share-link-preview">${esc(link)}</p>
  <p class="ot-share-legal">WhatsApp determina cómo presenta enlaces e imágenes en sus estados. La publicación debe realizarla el usuario.</p>
 </div>`,[{id:'cancel',text:'Volver al reproductor',act:closeModal}]);
}
const premiumEmblem=(type='check')=>`<div class="premium-modal-emblem">${icon(type)}</div><div class="premium-modal-kicker">ONLYTV MIUSIC · MI ESPACIO</div>`;
function libraryWorking(title,text){
 S.libraryOperationBusy=true;
 premiumModal(title,`${premiumEmblem('music')}<p>${esc(text)}</p><div class="premium-modal-loader">Conectando de forma segura con tu biblioteca…</div>`,[]);
}
function launchManualSync(){
 if(S.libraryOperationBusy)return;
 libraryWorking('Sincronizando tu biblioteca','Estamos revisando favoritos, playlists, historial y artistas seguidos con la copia de tu cuenta.');
 native('syncLibrary');
}
function deleteLibraryOptions(){
 if(S.libraryOperationBusy)return;
 premiumModal('Gestionar datos de mi biblioteca',`${premiumEmblem('library')}<p>Selecciona exactamente dónde quieres eliminar tus datos. Solo se afectará tu perfil actual.</p>
 <div class="premium-modal-choices" role="group" aria-label="Dónde eliminar los datos">
  <label class="premium-modal-choice"><input type="checkbox" name="clear-scope" value="local" checked><span><strong>Solo celular</strong><small>Borra los datos de este dispositivo. Tu respaldo en el servidor se conserva para recuperarlo después.</small></span></label>
  <label class="premium-modal-choice"><input type="checkbox" name="clear-scope" value="both"><span><strong>Celular y servidor</strong><small>Borra favoritos, playlists, historial, búsquedas y artistas seguidos del perfil. No se puede deshacer.</small></span></label>
 </div>
 <div class="premium-modal-info">${icon('clock')} Si seleccionas «Solo celular», la copia remota no se volverá a descargar automáticamente; usa «Sincronizar mi biblioteca» cuando quieras recuperarla.</div>`,[
 {id:'cancel',text:'Cancelar',act:closeModal},
 {id:'continue',text:'Continuar',accent:true,act:()=>{
  const checked=document.querySelector('#modal input[name="clear-scope"]:checked');
  if(!checked){toast('Selecciona una opción');return;}
  confirmLibraryDeletion(checked.value);
 }}]);
}
function confirmLibraryDeletion(scope){
 const remote=scope==='both';
 premiumModal(remote?'Confirmar eliminación definitiva':'Confirmar limpieza del celular',`${premiumEmblem(remote?'close':'library')}
 <p>${remote?'Se eliminará toda tu biblioteca de este perfil, tanto del dispositivo como de MySQL. Esta acción no se puede deshacer.':'Se quitarán todos los datos de tu biblioteca en este celular. El servidor conservará tu respaldo.'}</p>
 <div class="premium-modal-info">${icon('user')} ${esc(S.username)} · Perfil ${esc((S.accountProfiles.find(x=>Number(x.id)===S.activeProfileId)||{}).name||'Principal')}</div>`,[
 {id:'back',text:'Volver',act:deleteLibraryOptions},
 {id:'confirm',text:remote?'Eliminar todo':'Borrar del celular',accent:!remote,danger:remote,act:()=>{
  libraryWorking('Eliminando datos',remote?'Confirmando la eliminación en el servidor y después en el celular.':'Conservando tu respaldo en la nube y limpiando este celular.');
  native('clearLibrary',scope);
 }}]);
}
function historyExitSelection(){S.historySelecting=false;S.historySelected.clear();if(S.page==='history')render();}
function clearHistoryConfirm(keys=null){
 if(S.libraryOperationBusy)return;
 const selected=Array.isArray(keys)?keys:[];
 const all=!selected.length;
 premiumModal(all?'Eliminar todo el historial':'Eliminar canciones seleccionadas',`${premiumEmblem('clock')}
 <p>${all?'¿Quieres quitar todo el historial de reproducción de este celular?':`¿Quieres quitar ${selected.length} ${selected.length===1?'canción':'canciones'} de este celular?`}</p>
 <div class="premium-modal-info">${icon('check')} Tu respaldo del servidor no se elimina. Puedes recuperarlo después pulsando «Sincronizar mi biblioteca».</div>`,[
 {id:'cancel',text:'Cancelar',act:closeModal},
 {id:'delete',text:all?'Borrar historial local':'Eliminar selección',danger:true,act:()=>{
   libraryWorking('Limpiando historial','Eliminando solamente del celular, sin modificar la copia guardada en el servidor…');
   native('clearHistoryOnDevice',JSON.stringify(selected));
 }}]);
}
const formatPlanDate=value=>{const date=String(value||'').slice(0,10);return /^\d{4}-\d{2}-\d{2}$/.test(date)?date.split('-').reverse().join('/'):'Sin información';};
const renewalText=()=>{
 const profile=S.accountProfiles.find(p=>Number(p.id)===S.activeProfileId);
 return `Hola, quiero renovar mi servicio OnlyTVMiusic.\nUsuario: ${S.username||'No disponible'}\n${profile?'Perfil: '+profile.name+'\n':''}Fecha de activación: ${formatPlanDate(S.startsOn)}\nFecha de vencimiento: ${formatPlanDate(S.expiresAt)}\nQuedo atento a la renovación.`;
};
const expiryTime=value=>{
 if(!value)return NaN;
 const raw=String(value).replace(' ','T');
 return Date.parse(raw+(raw.endsWith('Z')||/[+-]\d\d:\d\d$/.test(raw)?'':'-05:00'));
};
function showPlanAlert(expired,days,message=''){
 const overlay=$('plan-overlay'),title=$('plan-alert-title'),body=$('plan-alert-message'),buttons=$('plan-alert-actions');
 if(!overlay)return;
 S.planExpired=!!expired;
 overlay.classList.toggle('expired',!!expired);
 overlay.classList.remove('hidden');
 title.textContent=expired?'Tu servicio ha vencido':'Tu servicio está por vencer';
 body.textContent=message||(expired?
 'Tu acceso a OnlyTVMiusic ha finalizado. Solicita la renovación al administrador para volver a escuchar tu música.':
 `Faltan ${days} ${days===1?'día':'días'} para que termine tu servicio. Renueva a tiempo y sigue disfrutando tu música sin interrupciones.`);
 const details=$('plan-alert-details');
 if(details){details.innerHTML=`<div><span>CLIENTE</span><strong>${esc(S.username||'Cuenta OnlyTVMiusic')}</strong></div>
  <div><span>ACTIVACIÓN</span><strong>${esc(formatPlanDate(S.startsOn))}</strong></div>
  <div><span>VENCIMIENTO</span><strong>${esc(formatPlanDate(S.expiresAt))}</strong></div>`;}
 $('plan-alert-date').textContent=expired?'Servicio vencido · renovación necesaria':`Quedan ${Math.max(1,days)} días para tu vencimiento`;
 $('plan-alert-note').textContent=expired?'Este aviso permanecerá visible hasta que se confirme la renovación. Tus datos personales se conservan.':
 'Podrás seguir escuchando hasta el vencimiento. Tu biblioteca se mantiene respaldada.';
 buttons.innerHTML=`<button type="button" data-plan="whatsapp">${icon('music')} Renovar por WhatsApp</button>
 ${expired?'<button type="button" class="ghost" data-plan="retry">Comprobar renovación</button>':
 '<button type="button" class="ghost" data-plan="dismiss">Entendido, gracias</button>'}`;
}
function checkPlanNotice(){
 if(!S.loggedIn)return;
 const expires=expiryTime(S.expiresAt),now=Date.now();
 if(!Number.isFinite(expires))return;
 if(now>=expires){
  if(!S.planExpired){showPlanAlert(true,0);native('planExpiryReached');}
  return;
 }
 if(S.planExpired){S.planExpired=false;$('plan-overlay').classList.add('hidden');S.noticeShownFor='';}
 const remaining=expires-now,key=`${S.username}:${S.expiresAt}`;
 if(remaining>0&&remaining<=5*86400000&&S.noticeShownFor!==key){
  S.noticeShownFor=key;showPlanAlert(false,Math.ceil(remaining/86400000));
 }
}
function createPlaylist(){
 const body=`<div class="ot-playlist-modal-body">
 <div class="ot-playlist-modal-brand">${playlistCover(0,'ot-playlist-modal-cover')}<span class="ot-playlist-modal-kicker">ONLYTV MIUSIC · NUEVA COLECCIÓN</span></div>
 <p>Elige un nombre especial para tu lista y comienza a guardar la música que te acompaña.</p>
 <label class="ot-playlist-field-label" for="modal-input">Nombre de tu playlist</label>
 <div class="ot-playlist-field"><input id="modal-input" type="text" maxlength="80" placeholder="Ej. Mis canciones favoritas" autocomplete="off" spellcheck="false" aria-describedby="ot-playlist-limit"><small id="ot-playlist-limit">0 / 80</small></div>
 <div class="ot-playlist-preview"><span>${icon('music')}</span><div><small>VISTA PREVIA</small><strong id="ot-playlist-preview-name">Mi nueva playlist</strong></div></div>
 </div>`;
 premiumModal('Crear playlist',body,[
  {id:'cancel',text:'Cancelar',act:closeModal},
  {id:'save',text:'Crear playlist',accent:true,act:()=>{
   const name=String(($('modal-input')||{}).value||'').trim();
   if(!name){toast('Escribe un nombre para tu playlist');$('modal-input')?.focus();return;}
   const result=parse(native('createPlaylist',name),{});
   if(result.id){refreshLibrary();closeModal();switchPage('playlists');toast('Playlist creada correctamente');}
   else toast('No se pudo crear la playlist');
  }}]);
}
function addPlaylist(t){
 if(!S.playlists.length){premiumModal('Crea tu primera playlist',`${premiumEmblem('music')}<p>Aún no tienes listas. Crea una para guardar esta canción y organizar tu biblioteca.</p>`,[
  {id:'cancel',text:'Cancelar',act:closeModal},{id:'new',text:'Crear playlist',accent:true,act:()=>{closeModal();createPlaylist()}}]);return;}
 premiumModal('Guardar en una playlist',`<div class="ot-playlist-pick-heading">${icon('music')} Elige una lista para <strong>${esc(t.title||'esta canción')}</strong></div>
  <div class="ot-playlist-pick-list">${S.playlists.map((pl,i)=>`<button type="button" class="ot-playlist-pick-item" data-pick="${i}">${playlistCover(i)}<span><strong>${esc(pl.name)}</strong><small>${Math.max(0,Number(pl.size)||0)} canciones</small></span>${icon('plus')}</button>`).join('')}</div>`,[{id:'cancel',text:'Cerrar',act:closeModal}]);
 modal.pick=t;
}
function playlistRename(id){
 const pl=S.playlists.find(x=>x.id===id);if(!pl)return;
 premiumModal('Cambiar nombre',`<div class="ot-playlist-modal-body">${premiumEmblem('music')}<p>Personaliza el nombre de tu playlist. Las canciones no cambiarán.</p>
 <label class="ot-playlist-field-label" for="modal-input">Nombre de la playlist</label><div class="ot-playlist-field"><input id="modal-input" maxlength="80" value="${esc(pl.name)}" autocomplete="off"><small id="ot-playlist-limit">${pl.name.length} / 80</small></div></div>`,[
 {id:'cancel',text:'Cancelar',act:closeModal},
 {id:'save',text:'Guardar cambios',accent:true,act:()=>{const name=String(($('modal-input')||{}).value||'').trim();if(!name){toast('Escribe un nombre');return;}const yes=native('renamePlaylist',id,name);if(yes){refreshLibrary();closeModal();render();toast('Nombre actualizado');}else toast('No se pudo actualizar la playlist');}}
 ]);
}
function playlistDeleteConfirm(id){
 const pl=S.playlists.find(x=>x.id===id);if(!pl)return;
 premiumModal('Eliminar playlist',`${premiumEmblem('close')}<p>¿Eliminar <strong>${esc(pl.name)}</strong> de tu biblioteca? Las canciones originales no se borrarán del catálogo musical.</p>`,[
 {id:'cancel',text:'Conservar lista',act:()=>playlistMenu(id)},
 {id:'confirm',text:'Eliminar playlist',danger:true,act:()=>{const ok=native('deletePlaylist',id);if(ok){refreshLibrary();closeModal();switchPage('playlists');toast('Playlist eliminada');}else toast('No se pudo eliminar la playlist');}}
 ]);
}
function playlistMenu(id){
 const p=S.playlists.find(x=>x.id===id);if(!p)return;
 premiumModal('Administrar playlist',`<div class="ot-playlist-manage-head">${playlistCover(S.playlists.findIndex(x=>x.id===id))}<div><small>MI PLAYLIST</small><strong>${esc(p.name)}</strong><span>${Math.max(0,Number(p.size)||0)} canciones</span></div></div>
 <button type="button" class="ot-playlist-management-option" data-act="playlist-rename" data-id="${esc(id)}">${icon('music')} <span>Editar nombre</span>${icon('chevron')}</button>
 <button type="button" class="ot-playlist-management-option danger" data-act="playlist-delete-confirm" data-id="${esc(id)}">${icon('close')} <span>Eliminar playlist</span>${icon('chevron')}</button>`,[
 {id:'close',text:'Volver a mi música',act:closeModal}
 ]);
}
function onClick(e){
 const planButton=e.target.closest('[data-plan]');
 if(planButton){
  if(planButton.dataset.plan==='whatsapp'){native('openRenewalWhatsApp',renewalText());return;}
  if(planButton.dataset.plan==='dismiss'&&!S.planExpired)$('plan-overlay').classList.add('hidden');
  else if(planButton.dataset.plan==='retry'){
   if(S.loggedIn)native('verifySession');
   else {let u=$('username').value.trim(),p=$('password').value;
    if(u&&p)native('signIn',u,p);
    else toast('Debes reiniciar sesión después de la renovación.');
   }
  }
  return;
 }
 const pick=e.target.closest('[data-pick]');if(pick){let p=S.playlists[+pick.dataset.pick];if(p&&modal.pick){let yes=native('addToPlaylist',p.id,JSON.stringify(modal.pick));toast(yes?'Añadida a '+p.name:'La canción ya está en esa playlist');refreshLibrary();render()}closeModal();return}
 const modalButton=e.target.closest('[data-modal]');if(modalButton){let act=modal.buttons&&modal.buttons[modalButton.dataset.modal];if(act)act();return}
 const nav=e.target.closest('[data-page]');if(nav){switchPage(nav.dataset.page);return}
 const el=e.target.closest('[data-act]');if(!el)return;
 const a=el.dataset.act;
 if(a==='open-demos'){$('demo-picker').classList.remove('hidden');S.demoLoading=true;native('loadDemos');return}
 if(a==='close-demos'){$('demo-picker').classList.add('hidden');return}
 if(a==='demo-pick'){if(S.demoLoading)return;S.demoLoading=true;const id=Number(el.dataset.id);toast('Preparando acceso de prueba…');native('demoSignIn',id);return}
 if(a==='select-profile'){const id=Number(el.dataset.id);const profile=S.accountProfiles.find(p=>Number(p.id)===id);if(profile&&profile.busy){toast('Este perfil está en uso en otro dispositivo. Cierra esa sesión para liberarlo.');return}if(id>0){native('selectProfile',id);toast('Cargando tu música personal…')}return}
 if(a==='switch-profile'){native('switchProfile');return}
 if(a==='check-app-update'){native('checkAppUpdate');return}
 if(a==='profile-logout'){native('logout');return}
 if(a==='sync-library'){launchManualSync();return}
 if(a==='delete-library'){deleteLibraryOptions();return}
 if(a==='history-edit'){S.historySelected.clear();S.historySelecting=true;render();return;}
 if(a==='history-cancel'){historyExitSelection();return;}
 if(a==='history-toggle-all'){
   if(S.historySelected.size===S.history.length)S.historySelected.clear();
   else S.historySelected=new Set(S.history.map(historyKey));
   render();return;
 }
 if(a==='history-delete-selected'){
   if(!S.historySelected.size){toast('Marca al menos una canción');return;}
   clearHistoryConfirm([...S.historySelected]);return;
 }
 if(a==='clear-history'){clearHistoryConfirm();return}
 const list=S.listMap[el.dataset.list]||[];const idx=Math.max(0,Number(el.dataset.i)||0);const t=list[idx];
 if(a==='play'){playFrom(list,idx);return}
 if(a==='favorite'&&t){native('toggleFavorite',JSON.stringify(t));refreshLibrary();render();renderPlayer();return}
 if(a==='add-playlist'&&t){addPlaylist(t);return}
 if(a==='remove-playlist-track'&&t&&S.detail){if(native('removeFromPlaylist',S.detail.id,JSON.stringify(t))){toast('Quitada de la playlist');render()}return}
 if(a==='home'||a==='discover'){if(a==='discover')switchPage('search');else switchPage('home');return}
 if(['favorites','history','playlists','search','artists','albums','genres','profile'].includes(a)){switchPage(a);return}
 if(a==='support-whatsapp'){native('openRenewalWhatsApp',`Hola, equipo de soporte OnlyTVMiusic. Necesito ayuda con mi servicio.\nUsuario: ${S.username||'No disponible'}\nPerfil: ${(S.accountProfiles.find(x=>Number(x.id)===S.activeProfileId)||{}).name||'Principal'}.`);return;}
 if(a==='playlist-play-all'){const songs=parse(native('playlistTracks',el.dataset.id),[]);if(songs.length)playFrom(songs,0);else toast('Añade canciones para comenzar');return;}
 if(a==='playlist-rename'){playlistRename(el.dataset.id);return;}
 if(a==='playlist-delete-confirm'){playlistDeleteConfirm(el.dataset.id);return;}
 if(a==='new-playlist'){createPlaylist();return}
 if(a==='playlist-menu'){playlistMenu(el.dataset.id);return}
 if(a==='open-playlist'){switchPage('detail',{type:'playlist',id:el.dataset.id});return}
 if(a==='genre'){const q=el.dataset.query||'';S.searchTerm=q;switchPage('search');startSearch(q,false);return}
 if(a==='artist'){switchPage('detail',{type:'artist',name:el.dataset.name});return}
 if(a==='more-artist'&&S.detail&&S.detail.type==='artist'){loadArtistPage(S.detail.name);return}
 if(a==='retry-trends'){loadTrending(true);return}
 if(a==='refresh-charts'){if(S.chartState!=='loading'){S.chartState='loading';native('loadArtistCharts');render()}return}
 if(a==='album'){switchPage('detail',{type:'album',album:el.dataset.album,artist:el.dataset.artist});return}
 if(a==='follow'){native('followArtist',el.dataset.name);refreshLibrary();render();return}
 if(a==='close-player'){closePlayer();toast('Reproductor minimizado');return}
 if(a==='mini-toggle'||a==='toggle'){toggle();return}
 if(a==='prev'||a==='next'||a==='shuffle'||a==='repeat'){
  native('command',a.toUpperCase(),0);
  const nextRepeat=Number(S.playback.repeat||0)>0?0:1;
  const labels={prev:'Canción anterior',next:'Siguiente canción',shuffle:S.playback.shuffle?'Aleatorio desactivado':'Aleatorio activado',repeat:nextRepeat?'Repetición activada para toda la cola':'Repetición desactivada'};
  if(a==='repeat'){S.playback.repeat=nextRepeat;renderPlayer()}
  if(a==='shuffle'){S.playback.shuffle=!S.playback.shuffle;renderPlayer()}
  toast(labels[a]);return;
 }
 if(a==='queue'){openPlayerQueue();return}
 if(a==='share-track'){toast('Preparando tu tarjeta musical…');native('shareStatusCard');return}
 if(['share-card-chat','share-card-status','share-link-text','share-copy-link'].includes(a)){
  const method={'share-card-chat':'shareChatCard','share-card-status':'shareStatusCard','share-link-text':'shareLinkText','share-copy-link':'copyShareLink'}[a];
  closeModal();
  if(a==='share-card-chat'||a==='share-card-status')toast('Preparando la tarjeta con la portada real…');
  native(method);return;
 }
 if(a==='close-queue'){closePlayerQueue();toast('Lista cerrada');return}
 if(a==='queue-related-play'){
  const index=Number(el.dataset.i);
  if(Number.isInteger(index)&&index>=0&&index<S.playerSuggestions.length){
   const list=S.playerSuggestions.slice();
   closePlayerQueue();
   playFrom(list,index);
   toast('Reproduciendo canción seleccionada');
  }
  return;
 }
 if(a==='queue-play-index'){
  const index=Number(el.dataset.i);
  if(Number.isInteger(index)&&index>=0){native('command','PLAY_INDEX',index);toast('Cargando canción seleccionada');S.queueLastKey='';closePlayerQueue()}
  return;
 }
 if(a==='filter'){
   const selected=el.dataset.filter||'all',current=($('query')||{}).value||'';
   const trimmed=current.trim();
   if(trimmed && trimmed!==S.searchTerm){startSearch(trimmed,false);S.searchFilter=selected;render();return}
   S.searchFilter=selected;render();return
 }
 if(a==='player-heart'){let track=playerTrack();if(track){native('toggleFavorite',JSON.stringify(track));refreshLibrary();renderPlayer();toast(S.favorites.some(x=>x.id===track.id&&x.provider===track.provider)?'Añadida a favoritos':'Quitada de favoritos')}return}
 if(a==='verify'){native('verifySession');toast('Verificando tu sesión con el servidor');return}
 if(a==='logout'){
  if(S.logoutBusy){toast('Estamos confirmando el cierre de sesión.');return}
  modal('Cerrar sesión',`<p>Al cerrar sesión, tu cuenta podrá utilizarse en otro dispositivo cuando el servidor confirme la liberación.</p>`,[
   {id:'cancel',text:'Cancelar',act:closeModal},
   {id:'yes',text:'Cerrar sesión',accent:true,act:()=>{
      if(S.logoutBusy)return;
      S.logoutBusy=true;
      modal('Cerrando sesión',`<p>Confirmando el cierre con ONLYTV MÚSICA. Mantén tu conexión activa.</p>`,[]);
      native('logout');
   }}]);return
 }
}
function attach(){
 document.addEventListener('click',onClick);
 const eye=$('password-visibility');
 eye.addEventListener('click',()=>{
  const field=$('password'),revealing=field.type==='password';
  field.type=revealing?'text':'password';
  eye.setAttribute('aria-label',revealing?'Ocultar contraseña':'Mostrar contraseña');
  eye.setAttribute('aria-pressed',String(revealing));
  $('password-eye-icon').setAttribute('href',revealing?'#i-eye-off':'#i-eye');
  field.focus({preventScroll:true});
 });
 const login=$('login');
 const viewport=window.visualViewport;
 const keepLoginFieldVisible=()=>{
   if(login.classList.contains('hidden'))return;
   const active=document.activeElement;
   if(active!==$('username')&&active!==$('password'))return;
   const viewportHeight=viewport?viewport.height:window.innerHeight;
   const bound=active.getBoundingClientRect();
   const padding=14;
   const bottom=viewportHeight-padding;
   // Only move by the number of pixels obscured by the keyboard.
   if(bound.bottom>bottom){login.scrollTop+=bound.bottom-bottom;}
   else if(bound.top<padding){login.scrollTop+=bound.top-padding;}
 };
 if(viewport){viewport.addEventListener('resize',()=>window.requestAnimationFrame(keepLoginFieldVisible));}
 ['username','password'].forEach(id=>{
   $(id).addEventListener('focus',()=>{
     setTimeout(keepLoginFieldVisible,120);
     setTimeout(keepLoginFieldVisible,340);
   });
 });
 document.addEventListener('submit',e=>{
  if(e.target.id==='login-form'){e.preventDefault();const btn=$('login-submit');if(btn.disabled)return;let u=$('username').value.trim(),p=$('password').value;btn.disabled=true;btn.innerHTML='Verificando acceso...';native('signIn',u,p)}
  if(e.target.id==='search-form'){e.preventDefault();let q=($('query').value||'').trim();if(q)startSearch(q,false)}
 });
 $('seek').addEventListener('input',()=>{S.seekHolding=true;$('elapsed').textContent=fmt(Number($('seek').value))});
 $('seek').addEventListener('change',()=>{native('command','SEEK',Number($('seek').value));S.seekHolding=false;toast('Buscando posición '+fmt(Number($('seek').value)))});
 $('mini-open').addEventListener('click',currentOpen);
 $('mini-cover').addEventListener('click',currentOpen);
 // Banner artwork stays uncluttered. Swipe left/right to change the image.
 let bannerTouch=null;
 document.addEventListener('touchstart',e=>{
  if(!e.target.closest('.home-banner')||!e.touches.length||S.banners.length<2)return;
  bannerTouch={x:e.touches[0].clientX,y:e.touches[0].clientY};
 },{passive:true});
 document.addEventListener('touchend',e=>{
  if(!bannerTouch||!e.changedTouches.length)return;
  const dx=e.changedTouches[0].clientX-bannerTouch.x;
  const dy=e.changedTouches[0].clientY-bannerTouch.y;
  bannerTouch=null;
  if(Math.abs(dx)<45||Math.abs(dx)<Math.abs(dy)*1.3||S.banners.length<2)return;
  S.bannerIndex=(S.bannerIndex+(dx<0?1:-1)+S.banners.length)%S.banners.length;
  render();
 },{passive:true});
 document.addEventListener('input',e=>{
  if(e.target.id!=='modal-input')return;
  const name=e.target.value||'';
  const count=$('ot-playlist-limit');if(count)count.textContent=`${name.length} / 80`;
  const preview=$('ot-playlist-preview-name');if(preview)preview.textContent=name.trim()||'Mi nueva playlist';
 });
 document.addEventListener('change',e=>{
  const cb=e.target.closest('input[data-history-key]');if(!cb)return;
  const key=cb.dataset.historyKey;
  if(cb.checked)S.historySelected.add(key);else S.historySelected.delete(key);
  render();
 });
 $('overlay').addEventListener('click',e=>{if(e.target===$('overlay'))closeModal()});
 $('overlay').addEventListener('change',e=>{
  const cb=e.target.closest('input[name="clear-scope"]');if(!cb)return;
  document.querySelectorAll('#modal input[name="clear-scope"]').forEach(x=>x.checked=(x===cb));
 });
}
window.OnlyTVApp={
 back(){if(S.planExpired)return;if(!$('plan-overlay').classList.contains('hidden')){$('plan-overlay').classList.add('hidden');return}if(S.libraryOperationBusy)return;if(!$('demo-picker').classList.contains('hidden')){$('demo-picker').classList.add('hidden');return}if(!$('overlay').classList.contains('hidden')){closeModal();return}if(S.queueOpen){closePlayerQueue();return}if(S.playerOpen){closePlayer();return}if(S.page==='detail'){switchPage(S.detail&&S.detail.type==='playlist'?'playlists':'search');return}if(S.page!=='home'){switchPage('home');return}native('leave')},
 refreshNative(){const prior=S.loggedIn;hydrate();if(!prior&&S.loggedIn)toast('Bienvenido a ONLYTV MÚSICA')},
 onPlanExpired(message){showPlanAlert(true,0,message);},
 onLibraryOperation(ok,message){
  S.libraryOperationBusy=false;S.historySelecting=false;S.historySelected.clear();refreshLibrary();if(S.loggedIn)hydrate();
  premiumModal(ok?'Operación completada':'No se pudo completar',`${premiumEmblem(ok?'check':'close')}
   <p>${esc(message||'No se recibió confirmación del servidor.')}</p>
   <div class="premium-modal-info">${icon(ok?'check':'clock')}${ok?'La operación se confirmó correctamente.':'No se ha confirmado el cambio. Comprueba la conexión e inténtalo de nuevo.'}</div>`,
   [{id:'done',text:'Entendido',accent:true,act:closeModal}]);
 },
 onSearch(res){
  if(!S.loggedIn)return;
  if(res.trending===true){
   if(S.trendingRequestId!==0&&res.id!==S.trendingRequestId)return;
   S.trendingLoading=false;
   if(Array.isArray(res.results)&&res.results.length){S.trending=res.results;S.trendingError=''}
   else S.trendingError=res.error||'La fuente musical no respondió.';
   if(S.page==='home')render();
   return;
  }
  if(res.id!==S.requestId && S.requestId!==0)return;
  S.loading=false;
  S.results=Array.isArray(res.results)?res.results:[];
  if(res.error)toast(res.error);render();
 },
 onDemos(data){
  S.demoLoading=false;
  const list=data&&Array.isArray(data.demos)?data.demos:[];
  $('demos-list').innerHTML=list.length?list.map((d,i)=>`<button class="demo-choice" data-act="demo-pick" data-id="${Number(d.id)}"><img src="avatars/${/^avatar[1-8]$/.test(d.avatar||'')?d.avatar:'avatar1'}.png" alt="Cuenta de prueba"><div><strong>${esc(d.name)}</strong><small>Acceso temporal · 45 minutos</small></div>${icon('chevron')}</button>`).join(''):
   empty('No hay demostraciones disponibles','Todas las pruebas están ocupadas o aún no se han publicado desde el panel.');
 },
 onDemoAuth(ok,message){S.demoLoading=false;if(!ok){toast(message);return;}$('demo-picker').classList.add('hidden');S.noticeShownFor='';hydrate();toast('¡Bienvenido a OnlyTV MÚSICA!')},
 onAuth(ok,message){let b=$('login-submit');b.disabled=false;b.innerHTML='<span>Ingresar</span><svg class="i"><use href="#i-chevron"></use></svg>';
  if(!ok&&String(message).startsWith('DEVICE_IN_USE:')){
    $('login-message').textContent='';
    modal('Vinculación de dispositivo',`<p>${esc(String(message).split(':').slice(1).join(':'))}</p><p>Si formateaste o cambiaste tu celular, este traslado cerrará las sesiones de la cuenta que existan en otros dispositivos.</p>`,[
      {id:'cancel',text:'Cancelar',act:closeModal},
      {id:'transfer',text:'Trasladar acceso aquí',accent:true,act:()=>{closeModal();let u=$('username').value.trim(),p=$('password').value;if(!u||!p){toast('Introduce tus credenciales');return}b.disabled=true;native('transferSignIn',u,p)}}]);return;
  }
  if(!ok&&String(message).startsWith('PLAN_EXPIRED:')){
   $('login-message').textContent='';hydrate();showPlanAlert(true,0,String(message).slice('PLAN_EXPIRED:'.length));return;
  }
  $('login-message').textContent=ok?'':message;
  if(ok){S.noticeShownFor='';$('password').value='';hydrate()}},
 onLogout(ok,message){
  S.logoutBusy=false;closeModal();
  if(ok){S.loading=false;S.requestId=0;S.trendingRequestId=0;S.trendingRequested=false;S.trendingLoading=false;S.trendingCacheLoaded=false;S.queueOpen=false;S.playback={};S.trending=[];S.results=[];S.page='home';closePlayer();S.bannersLoaded=false;S.banners=[];S.bannerIndex=0;S.bannerLoadedAt=0;hydrate();toast(message);return}
  modal('No se pudo confirmar el cierre',`<p>${esc(message)}</p><p>Para liberar este perfil debemos confirmar el cierre en el servidor. Reintenta cuando tengas conexión.</p>`,[
   {id:'cancel',text:'Seguir conectado',act:closeModal},
   {id:'again',text:'Reintentar',accent:true,act:()=>{S.logoutBusy=true;modal('Cerrando sesión',`<p>Confirmando el cierre con ONLYTV MÚSICA.</p>`,[]);native('logout')}}
  ]);
 },
 onLocalLogout(ok,message){S.logoutBusy=false;closeModal();if(ok){S.loading=false;S.requestId=0;S.trendingRequestId=0;S.trendingRequested=false;S.trendingLoading=false;S.trendingCacheLoaded=false;S.queueOpen=false;S.playback={};S.trending=[];S.results=[];S.page='home';closePlayer();S.bannersLoaded=false;S.banners=[];hydrate()}toast(message)},
 onArtistInfo(data){
  if(!data||!data.query)return;
  S.artistInfoPending[data.query]=false;
  S.artistInfo[data.query]=data;
  if(S.page==='detail'&&S.detail&&S.detail.type==='artist'&&S.detail.name===data.query)render();
 },
 onArtistCharts(data){
  S.chartArtists=data&&Array.isArray(data.artists)?data.artists.filter(a=>a&&a.name&&/^https:\/\//i.test(a.image||'')).slice(0,20):[];
  S.chartState=S.chartArtists.length?'ready':'unavailable';S.chartLoadedAt=Date.now();
  if(S.loggedIn&&(S.page==='home'||S.page==='artists'))render();
 },
 onArtistSearch(data){
  const name=data&&data.name,state=S.artistSearch[name];if(!state)return;
  if(Number(data.page)!==state.page)return;
  state.loading=false;
  if(data.error){state.error=data.error;state.hasMore=false}
  else{
   const ids=new Set(state.items.map(t=>t.id));
   (data.results||[]).forEach(t=>{if(t&&t.id&&!ids.has(t.id)){state.items.push(t);ids.add(t.id)}});
   state.page+=1;state.hasMore=!!data.hasMore&&state.page<12;
  }
  const viewing=S.page==='detail'&&S.detail&&S.detail.type==='artist'&&S.detail.name===name;
  if(viewing)render();
  // Search pages can contain very few songs matching the actual artist.
  // Load a few extra pages automatically instead of making the customer tap
  // "Cargar más" repeatedly just to see the first handful of songs.
  // Cap the automatic work: further pages stay under the customer's control.
  if(viewing && !state.error && state.hasMore && state.items.length<12 && state.page<4){
    setTimeout(()=>{
      if(S.page==='detail'&&S.detail&&S.detail.type==='artist'&&S.detail.name===name)
        loadArtistPage(name);
    },120);
  }
 },
 onBanners(data){S.banners=(data&&Array.isArray(data.banners)?data.banners:[]).filter(b=>panelBannerUrl(b.image_url));S.bannerIndex=0;if(S.loggedIn&&S.page==='home')render();},
 onAlreadyPlayingSong(){currentOpen();toast('La canción compartida ya está abierta.');},
 onSharedSong(track){
  if(!S.loggedIn||!S.sessionReady||S.activeProfileId<1)hydrate();
  if(!track||track.provider!=='newpipe'||!ytVideoId(track)){toast('El enlace no contiene una canción válida.');return;}
  if(!S.loggedIn||!S.sessionReady||S.activeProfileId<1){toast('Inicia sesión y elige tu perfil para abrir esta canción.');return;}
  S.playContext={kind:'share',title:'Canción compartida',list:[track]};
  native('play',JSON.stringify([track]),0);
  S.playback={...S.playback,track,title:track.title,artist:track.artist,loading:true,phase:'Preparando la canción compartida'};
  currentOpen();native('ackSharedSong',ytVideoId(track));toast('Abriendo la canción compartida…');
 },
 onShareResult(ok,message){toast(message|| (ok?'Tarjeta lista para compartir':'No se pudo compartir'))},
 notify:toast
};
function tick(){if(!S.loggedIn)return;checkPlanNotice();if(S.planExpired)return;S.playback=parse(native('playback'),S.playback);renderPlayer()}
// La bienvenida no altera sesión, reproducción ni estado del usuario.
function launchIntro(){
 const splash=$('launch-screen');if(!splash)return;
 const reduce=window.matchMedia&&window.matchMedia('(prefers-reduced-motion: reduce)').matches;
 let finished=false;
 const finish=()=>{
  if(finished)return;finished=true;
  splash.classList.add('launch-out');
  window.setTimeout(()=>{splash.classList.add('hidden');splash.setAttribute('aria-hidden','true');},reduce?0:560);
 };
 const skip=$('launch-skip');if(skip)skip.addEventListener('click',finish,{once:true});
 window.setTimeout(finish,4450);
}
attach();hydrate();native('webReady');launchIntro();setInterval(tick,900);
 setInterval(()=>{if(!S.loggedIn||S.page!=='home'||S.playerOpen||S.banners.length<2)return;S.bannerIndex=(S.bannerIndex+1)%S.banners.length;render();},6500);
})();
