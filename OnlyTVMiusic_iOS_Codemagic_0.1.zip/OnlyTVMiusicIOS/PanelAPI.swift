import Foundation

struct APIResult {
    let status: Int
    let json: [String: Any]
}

enum PanelAPI {
    // Mismo dominio HTTPS que en MainActivity.java del proyecto Android.
    static let base = URL(string: "https://onlytvmiusic.onlytvtumbes.com")!

    static func request(_ method: String, _ path: String, body: [String: Any]? = nil) async throws -> APIResult {
        guard path.hasPrefix("/api/"), let url = URL(string: path, relativeTo: base)?.absoluteURL,
              url.host == base.host, url.scheme == "https" else { throw URLError(.badURL) }
        var request = URLRequest(url: url)
        request.httpMethod = method
        request.cachePolicy = .reloadIgnoringLocalAndRemoteCacheData
        request.timeoutInterval = 15
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        request.setValue("no-store", forHTTPHeaderField: "Cache-Control")
        if path != "/api/login" && path != "/api/demo-login",
           let token = TokenStore.read("sessionToken"), !token.isEmpty {
            request.setValue("Bearer " + token, forHTTPHeaderField: "Authorization")
        }
        if let body {
            request.setValue("application/json; charset=utf-8", forHTTPHeaderField: "Content-Type")
            request.httpBody = try JSONSerialization.data(withJSONObject: body)
        }
        let (data, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse,
              http.url?.host == base.host,
              (200...599).contains(http.statusCode), data.count <= 262_144,
              let json = try JSONSerialization.jsonObject(with: data) as? [String: Any]
        else { throw URLError(.badServerResponse) }
        return APIResult(status: http.statusCode, json: json)
    }
}
