import SwiftUI
import WebKit
import UIKit

/// Prototipo iOS: conserva la interfaz local del proyecto Android.
/// Compatibles en esta etapa: login, verificación, demo, perfiles y banners.
/// NO hay catálogo musical ni reproducción implementados todavía.
struct OnlyTVWebScreen: UIViewRepresentable {
    func makeCoordinator() -> Coordinator { Coordinator() }

    func makeUIView(context: Context) -> WKWebView {
        let content = WKUserContentController()
        content.add(context.coordinator, name: "onlytv")
        let configuration = WKWebViewConfiguration()
        configuration.userContentController = content
        configuration.defaultWebpagePreferences.allowsContentJavaScript = true
        configuration.websiteDataStore = .nonPersistent()
        let web = WKWebView(frame: .zero, configuration: configuration)
        web.isOpaque = false
        web.backgroundColor = .black
        web.scrollView.backgroundColor = .black
        web.navigationDelegate = context.coordinator
        context.coordinator.web = web
        if let page = Bundle.main.url(forResource: "index", withExtension: "html", subdirectory: "premium") {
            web.loadFileURL(page, allowingReadAccessTo: page.deletingLastPathComponent())
        }
        return web
    }

    func updateUIView(_ web: WKWebView, context: Context) {}

    static func dismantleUIView(_ web: WKWebView, coordinator: Coordinator) {
        web.configuration.userContentController.removeScriptMessageHandler(forName: "onlytv")
        web.navigationDelegate = nil
    }

    final class Coordinator: NSObject, WKNavigationDelegate, WKScriptMessageHandler {
        weak var web: WKWebView?
        private var screenReady = false
        private var verifying = false
        private var state: [String: Any] = [
            "loggedIn": false, "sessionReady": false, "username": "", "profiles": [],
            "accountType": "normal", "isDemo": false, "startsOn": "", "expiresAt": "",
            "activeProfileId": 0, "profileSelectionRequired": false, "favorites": [],
            "history": [], "playlists": [], "recent": [], "followed": [], "playback": [:]
        ]

        override init() {
            super.init()
            state["username"] = UserDefaults.standard.string(forKey: "username") ?? ""
            state["loggedIn"] = !(TokenStore.read("sessionToken") ?? "").isEmpty
            state["sessionReady"] = false // Nunca autorizar música antes de /api/me
        }

        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            screenReady = true
            refresh()
            verifySession()
        }

        func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction,
                     decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
            // HTML embebido únicamente. No mostrar sitios externos en el contenedor autenticado.
            if navigationAction.targetFrame?.isMainFrame == true,
               navigationAction.request.url?.isFileURL != true {
                decisionHandler(.cancel)
            } else { decisionHandler(.allow) }
        }

        func userContentController(_ userContentController: WKUserContentController,
                                   didReceive message: WKScriptMessage) {
            guard message.name == "onlytv", message.frameInfo.isMainFrame,
                  let body = message.body as? [String: Any],
                  let name = body["name"] as? String,
                  let args = body["args"] as? [Any] else { return }
            switch name {
            case "webReady": refresh()
            case "signIn", "transferSignIn":
                let user = args.count > 0 ? args[0] as? String ?? "" : ""
                let password = args.count > 1 ? args[1] as? String ?? "" : ""
                login(user: user, password: password, transfer: name == "transferSignIn")
            case "logout": logout(offline: false)
            case "localLogout": logout(offline: true)
            case "verifySession": verifySession()
            case "loadDemos": loadDemos()
            case "demoSignIn": if let id = args.first as? Int { demoLogin(id) }
            case "selectProfile": if let id = args.first as? Int { claimProfile(id, restoring: false) }
            case "loadBanners": loadBanners()
            case "search":
                let id = args.count > 2 ? args[2] as? Int ?? 0 : 0
                let trending = args.count > 1 ? args[1] as? Bool ?? false : false
                event("onSearch", [["id": id, "trending": trending, "results": [],
                    "error": "El catálogo NewPipe de Android aún no está adaptado a iPhone."]])
            case "openRenewalWhatsApp":
                if let msg = args.first as? String, msg.count <= 700,
                   let encoded = msg.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed),
                   let url = URL(string: "https://wa.me/51986385469?text=" + encoded) {
                    UIApplication.shared.open(url)
                }
            case "switchProfile": notice("Para cambiar de perfil, primero cierra sesión.")
            default: break
            }
        }

        private func json(_ object: Any) -> String {
            guard JSONSerialization.isValidJSONObject(object),
                  let data = try? JSONSerialization.data(withJSONObject: object, options: [.fragmentsAllowed, .sortedKeys]),
                  let result = String(data: data, encoding: .utf8) else { return "null" }
            return result
        }

        private func javascript(_ script: String) {
            guard screenReady else { return }
            web?.evaluateJavaScript(script, completionHandler: nil)
        }

        private func event(_ name: String, _ args: [Any]) {
            guard ["onAuth", "onLogout", "onLocalLogout", "onDemoAuth", "onDemos", "onBanners", "onSearch"].contains(name) else { return }
            javascript("window.OnlyTVApp && window.OnlyTVApp.\(name).apply(window.OnlyTVApp, \(json(args)));")
        }

        private func notice(_ message: String) {
            let data = json([message])
            javascript("window.OnlyTVApp && window.OnlyTVApp.notify.apply(window.OnlyTVApp, \(data));")
        }

        private func refresh() {
            state["profileSelectionRequired"] = (state["loggedIn"] as? Bool ?? false)
                && (state["accountType"] as? String == "familiar")
                && (state["activeProfileId"] as? Int ?? 0) == 0
            javascript("window.__OnlyTViOSBoot = \(json(state)); window.OnlyTVApp && window.OnlyTVApp.refreshNative();")
        }

        private func fillAccount(_ response: [String: Any], newLogin: Bool) {
            let kind = response["account_type"] as? String == "familiar" ? "familiar" : "normal"
            let profiles = response["profiles"] as? [[String: Any]] ?? []
            let oldID = state["activeProfileId"] as? Int ?? 0
            let oldValid = profiles.contains { ($0["id"] as? Int ?? 0) == oldID }
            var profileID = oldID
            if newLogin || !oldValid {
                profileID = kind == "normal" ? (profiles.first?["id"] as? Int ?? 0) : 0
            }
            state["loggedIn"] = true
            state["accountType"] = kind
            state["profiles"] = profiles
            state["isDemo"] = response["is_demo"] as? Bool ?? false
            state["startsOn"] = response["starts_on"] as? String ?? ""
            state["expiresAt"] = response["expires_at"] as? String ?? ""
            state["activeProfileId"] = profileID
            state["sessionReady"] = kind != "familiar" // familiar necesita confirmar lease
            refresh()
        }

        private func applyTokenLogin(_ result: APIResult, username: String, demo: Bool) -> Bool {
            guard result.status == 200,
                  let token = result.json["token"] as? String,
                  token.count == 64, token.allSatisfy({ $0.isHexDigit }) else { return false }
            TokenStore.write(token, key: "sessionToken")
            let name = demo ? result.json["username"] as? String ?? "Demo" : username
            UserDefaults.standard.set(name, forKey: "username")
            state["username"] = name
            fillAccount(result.json, newLogin: true)
            return true
        }

        private func login(user: String, password: String, transfer: Bool) {
            let clean = user.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !clean.isEmpty, !password.isEmpty else { event("onAuth", [false,"Escribe usuario y contraseña."]); return }
            Task { @MainActor in
                do {
                    let r = try await PanelAPI.request("POST", "/api/login", body: [
                        "username": clean, "password": password, "device_id": TokenStore.deviceID(),
                        "transfer_device": transfer
                    ])
                    if applyTokenLogin(r, username: clean, demo: false) { event("onAuth", [true,"Bienvenido a OnlyTVMiusic"]) }
                    else {
                        let code = r.json["code"] as? String ?? ""
                        let message: String
                        switch r.status {
                        case 401: message = "Usuario o contraseña incorrectos."
                        case 409: message = code == "FAMILY_DEVICE_LIMIT" ? "El plan familiar alcanzó el límite de dispositivos." : "DEVICE_IN_USE:La cuenta ya está asociada a otro dispositivo."
                        case 403: message = r.json["error"] as? String ?? "Cuenta no disponible."
                        default: message = r.json["error"] as? String ?? "No se pudo iniciar sesión."
                        }
                        event("onAuth", [false,message])
                    }
                } catch { event("onAuth", [false,"No se pudo conectar con el servidor. Verifica tu conexión."]) }
            }
        }

        private func verifySession() {
            guard !verifying, TokenStore.read("sessionToken") != nil else { return }
            verifying = true
            Task { @MainActor in
                defer { verifying = false }
                do {
                    let response = try await PanelAPI.request("GET", "/api/me")
                    if response.status == 200 && response.json["status"] as? String == "active" {
                        if let name = response.json["username"] as? String { state["username"] = name }
                        fillAccount(response.json, newLogin: false)
                        if (state["accountType"] as? String) == "familiar",
                           (state["activeProfileId"] as? Int ?? 0) > 0 {
                            claimProfile(state["activeProfileId"] as? Int ?? 0, restoring: true)
                        }
                    } else if response.status == 401 { clearLocalSession() }
                    else { state["sessionReady"] = false; refresh() }
                } catch {
                    state["sessionReady"] = false; refresh()
                    notice("No se pudo comprobar la sesión. Revisa tu conexión.")
                }
            }
        }

        private func claimProfile(_ id: Int, restoring: Bool) {
            guard id > 0, (state["loggedIn"] as? Bool) == true,
                  (state["profiles"] as? [[String: Any]] ?? []).contains(where: { ($0["id"] as? Int) == id })
            else { return }
            Task { @MainActor in
                do {
                    let result = try await PanelAPI.request("POST", "/api/profile/claim", body: ["profile_id": id])
                    if result.status == 200 && result.json["ok"] as? Bool == true {
                        state["activeProfileId"] = id
                        state["sessionReady"] = true
                        if let profiles = result.json["profiles"] as? [[String: Any]] { state["profiles"] = profiles }
                        refresh()
                    } else {
                        state["sessionReady"] = false
                        if restoring && result.status == 409 { state["activeProfileId"] = 0 }
                        refresh()
                        notice(result.status == 409 ? "Perfil ocupado en otro dispositivo." : "No se pudo reservar el perfil.")
                    }
                } catch { state["sessionReady"] = false; refresh(); notice("No se pudo validar el perfil.") }
            }
        }

        private func logout(offline: Bool) {
            if offline {
                clearLocalSession()
                event("onLocalLogout", [true,"Saliste de este iPhone; puede quedar una sesión activa en el servidor."])
                return
            }
            Task { @MainActor in
                do {
                    let result = try await PanelAPI.request("POST", "/api/logout", body: [:])
                    if (result.status == 200 && result.json["ok"] as? Bool == true) || result.status == 401 {
                        clearLocalSession()
                        event("onLogout", [true,"Sesión cerrada."])
                    } else { event("onLogout", [false,"No se confirmó el cierre de sesión."]) }
                } catch { event("onLogout", [false,"Sin conexión. Tu sesión sigue guardada."]) }
            }
        }

        private func clearLocalSession() {
            TokenStore.delete("sessionToken")
            state["loggedIn"] = false
            state["sessionReady"] = false
            state["activeProfileId"] = 0
            state["profiles"] = []
            state["favorites"] = []
            state["history"] = []
            state["playlists"] = []
            refresh()
        }

        private func demoLogin(_ id: Int) {
            guard id > 0 else { return }
            Task { @MainActor in
                do {
                    let result = try await PanelAPI.request("POST", "/api/demo-login", body: [
                        "demo_id": id, "device_id": TokenStore.deviceID()
                    ])
                    event("onDemoAuth", [applyTokenLogin(result, username: "Demo", demo: true),
                         result.status == 200 ? "Bienvenido a la demostración." : "No hay una demo disponible."])
                } catch { event("onDemoAuth", [false,"No se pudo conectar con el servidor."]) }
            }
        }

        private func loadDemos() {
            Task { @MainActor in
                let result = try? await PanelAPI.request("GET", "/api/demos")
                event("onDemos", [result?.status == 200 ? result!.json : [:]])
            }
        }

        private func loadBanners() {
            Task { @MainActor in
                let result = try? await PanelAPI.request("GET", "/api/banners")
                event("onBanners", [result?.status == 200 ? result!.json : [:]])
            }
        }
    }
}
