import SwiftUI

@main
struct OnlyTVMiusicApp: App {
    var body: some Scene {
        WindowGroup {
            OnlyTVWebScreen()
                .ignoresSafeArea(edges: .bottom)
                .preferredColorScheme(.dark)
        }
    }
}
