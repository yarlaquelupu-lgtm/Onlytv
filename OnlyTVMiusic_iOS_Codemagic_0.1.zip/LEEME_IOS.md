# ONLYTV MIUSIC — Base inicial para iPhone (0.1, NO versión final)

Este es un **primer proyecto iOS de migración** preparado a partir de `OnlyTVMiusic_ANDROID_0.7.21.rar`.
No se ha modificado el proyecto Android.

## Contenido implementado

- Reutiliza los archivos originales `premium/index.html`, `app.js`, `style.css`, imágenes y avatares.
- Crea un contenedor de iPhone con `WKWebView` y una capa JS de compatibilidad asíncrona.
- Solicitudes HTTPS a la API del mismo dominio que Android, sin credenciales incrustadas.
- Inicio de sesión, transferencia de dispositivo, sesión demo, lectura de `/api/me`, cierre de sesión, banners y reserva de perfil familiar (`/api/profile/claim`).
- Token en Keychain y un `device_id` iOS persistente distinto del de Android.
- Ícono reutilizado del proyecto Android.

## AÚN NO IMPLEMENTADO

**Esta base NO es una conversión completa ni una aplicación lista para instalar.**

- Búsqueda, tendencias y reproducción de audio: Android usa NewPipeExtractor y Media3; estos no se ejecutan en iOS. Se necesita un catálogo y proveedor de audio autorizado compatible con iOS, además de AVPlayer / AVAudioSession.
- Favoritos, bibliotecas, sincronización e historial de perfiles: todavía falta trasladar los datos locales y los endpoints de biblioteca.
- Carátulas, rankings y datos de artistas; enlaces compartidos y universal links.
- Tarjetas para compartir canciones, comandos de audio, pantalla bloqueada, controles remotos, audio de fondo y descargas.
- Validación en iPhone real, pruebas de diferentes cuentas, firma y exportación de `.ipa`.
- No se garantizan el login ni la integración con el servidor sin comprobar su funcionamiento real.

La interfaz puede mostrar opciones que todavía no están activas en iOS. Algunos botones mostrarán «pendiente de adaptar». **No distribuir este prototipo a clientes.**

## Cómo abrir

1. En una **Mac** con Xcode abre `OnlyTVMiusic.xcodeproj` (incluido).
2. Selecciona el esquema OnlyTVMiusic y un iPhone o simulador iOS (iOS 15 o posterior).
3. En *Signing & Capabilities*, elige tu equipo de firma y cambia el *Bundle Identifier* si el identificador no te pertenece.
4. Ejecuta **Run**. No se ha compilado ni probado aquí: el entorno de creación no tiene Xcode.
5. Como alternativa, `project.yml` permite regenerar el proyecto con XcodeGen si fuera necesario.

## Antes de continuar la migración

- Asegura acceso autorizado al backend y comprueba la API de sesiones y perfiles familiares.
- Confirma los derechos y condiciones de las fuentes de música que usa OnlyTVMiusic; para distribuir en App Store Apple exige que la reproducción y las descargas de fuentes de terceros estén autorizadas.
- Sustituye el motor de audio, implementa bibliotecas, y valida con iPhone real.
- No uses el actual sistema de actualizaciones APK para iPhone.

La versión Android 0.7.21 usa `applicationId com.onlytvmiusic.app`, `versionCode 59`, Java 17, NewPipeExtractor y AndroidX Media3. Este proyecto iOS tiene identificador provisional `com.onlytvmiusic.ios`.
