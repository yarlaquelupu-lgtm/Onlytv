# Configurar Codemagic con OnlyTVMiusic usando Windows

Esta carpeta contiene el proyecto iOS **prototipo 0.1**, no la aplicación iOS final.
La primera prueba compilará una aplicacion **sin firma para simulador**, no un `.ipa` para un iPhone real.

## 1. GitHub
1. Entra a https://github.com/signup y crea o inicia sesión en tu cuenta.
2. En https://github.com/new crea un repositorio llamado `OnlyTVMiusic-iOS` y selecciona **Private**.
3. En tu PC descomprime `OnlyTVMiusic_iOS_Codemagic_0.1.zip`.
4. En el repositorio, selecciona **Add file > Upload files** y arrastra el contenido de la carpeta descomprimida. Debes subir la carpeta `OnlyTVMiusicIOS`, la carpeta `OnlyTVMiusic.xcodeproj` y `codemagic.yaml` **a la raiz del repositorio**. No subas el ZIP como unico archivo.
5. Confirma la subida con **Commit changes**. Comprueba que `codemagic.yaml` aparezca en la primera pagina del repositorio.
6. No publiques tokens, contraseñas, claves de API ni certificados en GitHub; usa un repositorio privado.

## 2. Codemagic
1. Entra en https://codemagic.io y regístrate/inicia sesión con GitHub.
2. Ve a **Applications > Add application**. Conecta GitHub y autoriza la integracion Codemagic CI/CD a este repositorio.
3. Selecciona el repositorio `OnlyTVMiusic-iOS` y el tipo **iOS App** (o **Native iOS**, según la interfaz).
4. Pulsa **Finish: Add application**.
5. Busca `codemagic.yaml` en el proyecto o usa **Check for configuration file** seleccionando la rama `main`.
6. Pulsa **Start new build**. Selecciona la rama `main` y el flujo `OnlyTVMiusic - probar compilacion iOS`.
7. Inicia la ejecución. Si termina correctamente, la salida estará en **Artifacts** como `OnlyTVMiusic-simulador.zip`.
8. Si falla, abre el registro de compilación y copia las últimas líneas del error para revisar el proyecto.

## 3. Limitaciones
- Una compilacion sin firma para simulador no es instalable en un iPhone real ni publica nada en App Store.
- Para obtener un `.ipa` distribuible se requiere Apple Developer Program, certificados y perfiles de aprovisionamiento; es una configuracion posterior.
- Aún faltan reproducción/búsqueda musical, biblioteca e integraciones reales en iOS; esta base es experimental.
- Las compilaciones en la nube pueden tener costes segun cuenta y consumo; revisa la sección Billing de Codemagic.

Documentación:
- https://docs.codemagic.io/yaml-quick-start/building-a-native-ios-app/
- https://docs.codemagic.io/yaml-code-signing/ios-simulator-builds/
- https://docs.codemagic.io/yaml-basic-configuration/yaml-getting-started/
